
/**
 * @author (Ángel Velázquez Iturbide, Departamento de Informática y Estadística, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos para Juegos, Grados en Diseño y Desarrollo de Videojuegos
 * @version (Curso 2020-21)
 */
public class Varios
{
   public static int suma (int n) {
      if (n==0)
         return 0;
      else
         return n + suma(n-1);
   }

   public static void numsD (int n) {
      if (n>0) {
         System.out.println(n);
         numsD(n-1);
      }
   }

   public static void numsA (int n) {
      if (n>0) {
         numsA(n-1);
         System.out.println(n);
      }
   }
   
   public static void digitos (int n) {
      if (n<10)
         System.out.println(n);
      else {
         digitos(n/10);
         System.out.println(n%10);
      }
   }


}
