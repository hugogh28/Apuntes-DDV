
/**
 * @author (Ángel Velázquez Iturbide, Departamento de Informática y Estadística, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos para Juegos, Grados en Diseño y Desarrollo de Videojuegos
 * @version (Curso 2020-21)
 */
public class Combinatorios
{
   public static int comb1 (int m, int n) {
      if (n==0)
         return 1;
      else if (m==n)
         return 1;
      else
         return comb1(m-1,n) + comb1(m-1,n-1);
   }
   
   public static int comb2 (int m, int n)  {
      int[][] combs = new int[m-n+1][n+1];
      for (int j=1; j<=n; j++)
         combs[0][j] = 1;
      for (int i=1; i<=m-n; i++) {
         combs[i][0] = 1;
         for (int j=1; j<=n; j++)
            combs[i][j] = combs[i-1][j] + combs[i][j-1];
        }
      return combs[m-n][n];
   }

   public static int comb3 (int m, int n) {
      int[] combs = new int[n+1];
      for (int j=0; j<=n; j++)
         combs[j] = 1;
      for (int i=1; i<=m-n; i++)
         for (int j=1; j<=n; j++)
            combs[j] = combs[j] + combs [j-1];
      return combs[n];
   }
   
   public static int comb4 (int m, int n) {
      int[][] combs = new int[m-n+1][n+1];
      for (int i=0; i<=m-n; i++)
         for (int j=0; j<=n; j++)
            combs[i][j] = 0;
      combMem (m, n, combs);
      return combs[m-n][n];
    }
   private static void combMem (int m, int n, int[][] combs) {
      if (combs[m-n][n] == 0)
         if (n==0||m==n)
            combs[m-n][n] = 1;
         else {
            combMem (m-1, n,  combs);
            combMem (m-1, n-1, combs);
            combs[m-n][n] = combs[m-n-1][n] + combs[m-n][n-1];
        }
    }
}
