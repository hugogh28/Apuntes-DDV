
/**
 * Write a description of class Potencia_1 here.
 * 
 * @author (
 * Ángel Velázquez Iturbide, Departamento de Informática y Estadística, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos para Juegos, Grados en Diseño y Desarrollo de Videojuegos
 * @version (Curso 2020-21)
 */
public class Potencia_1
{
   public static int menosUnoN_iter (int n) {
      int result = 1;
      for (int i=0; i<n; i++)
         result *= (-1);
      return result;
   }

   public static int menosUnoN_rec (int n) {
      if (n==0)
         return 1;
      else
         return (-1)*menosUnoN_rec(n-1);
   }

   public static int menosUnoN_B (int n) {
      if (n%2==0)
         return 1;
      else
         return -1;
   }

}
