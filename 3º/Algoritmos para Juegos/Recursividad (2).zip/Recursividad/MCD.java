
/**
 * @author (Ángel Velázquez Iturbide, Departamento de Informática y Estadística, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos para Juegos, Grados en Diseño y Desarrollo de Videojuegos
 * @version (Curso 2020-21)
 */
public class MCD
{
    public static int mcd1 (int m, int n) {
       if (m==0)
          return n;
       else if (m>n)
          return mcd1 (n,m);
       else
          return mcd1 (m,n-m);
    }
    
    public static int mcd2 (int m, int n) {
       if (m==0)
          return n;
       else if (m>n)
          return mcd2 (n,m);
       else
          return mcd2 (n%m,m);
    }
    
    public static int mcd3 (int m, int n) {
    // versi�n iterativa de mcd1
       int x=m; int y=n;
       while (x!=0)
          if (x>y) {
             int aux = x;
             x = y;
             y = aux;
          }
          else
            y = y-x;
       return y;
    }
}
