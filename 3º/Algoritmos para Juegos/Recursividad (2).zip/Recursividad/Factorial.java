
/**
 * @author (Ángel Velázquez Iturbide, Departamento de Informática y Estadística, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos para Juegos, Grados en Diseño y Desarrollo de Videojuegos
 * @version (Curso 2020-21)
 */
public class Factorial
{
    public static int factRec (int n) {
       if (n == 0)
          return 1;
       else
          return n*factRec(n-1);
    }
    
    public static int factIt1 (int n) {
       // algoritmo iterativo obtenido con el esquema general
       int y = n;
       while (y>0)
          y--;
       int f = 1;
       while (y!=n) {
          y++;
          f *= y;
       }
       return f;
    }
    
    public static int factIt2 (int n) {
       // algoritmo iterativo obtenido por conocer el caso b�sico
       int y = 0;
       int f = 1;
       while (y!=n) {
          y++;
          f *= y;
       }
       return f;
    }
    
   public static int factFor2 (int n) {
      int f = 1;
      for (int y=1; y<=n; y++)
         f *= y;
      return f;
   }

    public static int factIt3 (int n) {
       // algoritmo iterativo obtenido por cumplir * la propiedad pseudoconmutativa
       int y = n;
       int f = 1;
       while (y!=0) {
          f *= y;
          y--;
       }
       return f;
    }
    
    public static int factFor3 (int n) {
       int f = 1;
       for (int y=n; y<=1; y--)
          f *= y;
       return f;
    }

    public static int factIt4 (int n) {
       // algoritmo iterativo obtenido por conocer el caso b�sico
       int y = n;
       int f;
       if (y==0)
          f = 1;
       else {
          f = y; y--;
          while (y!=0) {
             f = f*y;
             y--;
          }
          f = f*1;
       }
       return f;
    }
}
