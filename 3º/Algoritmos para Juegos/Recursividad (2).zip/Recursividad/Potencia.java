
/**
 * @author (Ángel Velázquez Iturbide, Departamento de Informática y Estadística, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos para Juegos, Grados en Diseño y Desarrollo de Videojuegos
 * @version (Curso 2020-21)
 */
public class Potencia
{
    public static int pot1 (int b, int e) {
       if (e==0)
          return 1;
       else
          return b*pot1(b,e-1);
    }

    public static int pot1iter (int b, int e) {
       int p = 1;
       for (int i=1; i<=e; i++)
          p = p * b;
       return p;       
    }
        
    public static int pot2 (int b, int e) {
       if (e==0)
          return 1;
       else if (e%2==0)
          return pot2(b*b,e/2);
       else
          return b*pot2(b*b,e/2);
    }
    
    public static int pot2iter (int b, int e) {
       int r = b;
       int s = e;
       int p = 1;
       while (s>0) {
          if (s%2==1)
             p *= b;
          r *= r;
          s /= 2;
       }
       return p; 
    }

}