
/**
 * @author (Ángel Velázquez Iturbide, Departamento de Informática y Estadística, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos para Juegos, Grados en Diseño y Desarrollo de Videojuegos
 * @version (Curso 2020-21)
 */
public class Fib
{
    public static int fib1 (int n) {
       if (n==0 || n==1)
          return 1;
       else
          return fib1(n-1) + fib1(n-2);
    }
    
    public static int fib2 (int n) {
       // f2 >= f1
       int[] fibs = new int[n+1];
       fibs[0] = 1;
       fibs[1] = 1;
       for (int i=2; i<=n; i++)
          // (f1,f2) = (f2,f1+f2);
          fibs[i] = fibs[i-1]+fibs[i-2];
       return fibs[n];
    }
    
    public static int fib3 (int n) {
       // f2 >= f1
       int f1 = 1;
       int f2 = 1;
       for (int i=2; i<=n; i++) {
          // (f1,f2) = (f2,f1+f2);
          f2 = f1+f2;
          f1 = f2-f1;
       }
       return f2;
    }
    
    public static int fib4 (int n) {
       // f2 >= f1
       int f1 = 1;
       int f2 = 1;
       for (int i=1; i<=n/2; i++) {
          // (f1,f2) = (f2,f1+f2);
          f1 = f1+f2;
          f2 = f2+f1;
       }
       return (n%2==0)?f1:f2;
    }
    
    public static int fib5 (int n) {
       int[] fibs = new int[n+1];
       for (int i=0; i<=n; i++)
          fibs[i] = -1;
       fibMem (n, fibs);
       return fibs[n];
    }
   private static void fibMem (int n, int[] fibs) {
      if (fibs[n] == -1)
         if (n==0||n==1)
            fibs[n] = 1;
         else {
            fibMem (n-1, fibs);
            fibMem (n-2, fibs);
            fibs[n] = fibs[n-1]+fibs[n-2];
        }
    }
    
    public static int fibRabbit (int n) {
       return bebes(n) + adultos(n);
    }
    private static int bebes (int n) {
       if (n==0)
          return 1;
       else
          return adultos(n-1);
    }
    private static int adultos (int n) {
       if (n==0)
          return 0;
       else
          return adultos(n-1) + bebes(n-1);
    }

    public static int fibTree (int n) {
       if (n==0 || n==1)
          return 1;
       else {
          int f=1;
          for (int i=0; i<=n-2; i++)
             f += fibTree(i);
          return f;
        }
    }
}
