
/**
 * Write a description of class Mochila_0_1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mochila_01
{
   static int nodos;
   
   public static int mochila01_back (int[] ps, int[] bs, int c) {
      nodos = 1;
      int[] solParcial = new int[ps.length];
      int[] solOptima = new int[ps.length];
      int bOpt = buscar01a (ps, bs, c, 0, c, solParcial, 0, solOptima, -1);
      System.out.println("N�mero de nodos creados durante la b�squeda: " + nodos);
      System.out.print ("Soluci�n �ptima: "); imprimir (solOptima); System.out.println();
      return bOpt;
   }
   private static int buscar01a (int[] ps, int[] bs, int c,
                                 int i, int p,
                                 int[] solParc, int b,
                                 int[] solOpt, int bOpt) {
      // versi�n basada en el esquema de la t�cnica de vuelta atr�s para soluci�n �ptima
      if (i==ps.length) {
         if (b>bOpt) {
            bOpt = b;
            for (int j=0; j<ps.length; j++)
               solOpt[j] = solParc[j];
         }
      }
      else
         for (int k=0; k<=1; k++) {
            if (k*ps[i]<=p) {
               nodos++; 
               solParc[i] = k;
               int np = p - k*ps[i];
               int nb = b + k*bs[i];
               bOpt = buscar01a (ps, bs, c, i+1, np, solParc, nb, solOpt, bOpt);
               //int np = p + k*ps[i]; innecesarias porque en la primera iteraci�n k==0
               //int nb = b - k*bs[i];
            }
         }
      return bOpt;
   }
   
   public static int mochila01_despl (int[] ps, int[] bs, int c) {
      int[] solParcial = new int[ps.length];
      int[] solOptima = new int[ps.length];
      int bOpt = buscar01b (ps, bs, c, 0, c, solParcial, 0, solOptima, -1);
      System.out.println("N�mero de nodos creados durante la b�squeda: " + nodos);
      System.out.print ("Soluci�n �ptima: "); imprimir (solOptima); System.out.println();
      return bOpt;
   }
   private static int buscar01b (int[] ps, int[] bs, int c,
                                 int i, int p,
                                 int[] solParc, int b,
                                 int[] solOpt, int bOpt) {
      // versi�n optimizada, con el bucle desplegado y simplificado el c�digo de cada candidato
      if (i==ps.length) {
         if (b>bOpt) {
            bOpt = b;
            for (int j=0; j<ps.length; j++)
               solOpt[j] = solParc[j];
         }
      }
      else {
         //decisi�n 0
         nodos++;
         solParc[i] = 0;
         bOpt = buscar01a (ps, bs, c, i+1, p, solParc, b, solOpt, bOpt);
         //decisi�n 1
         nodos++;
         if (ps[i]<=p) {
            solParc[i] = 1;
            int np = p - ps[i];
            int nb = b + bs[i];
            bOpt = buscar01a (ps, bs, c, i+1, np, solParc, nb, solOpt, bOpt);
         }
      }
      return bOpt;
   }

   public static int mochila01_RyP1 (int[] ps, int[] bs, int c) {
      nodos = 1;
      int[] solParcial = new int[ps.length];
      int[] solOptima = new int[ps.length];
      // cota como suma de beneficios
      int cota = 0;
      for (int i=0; i<bs.length; i++)
         cota += bs[i];
      System.out.println ("Cota inicial: "+cota+". Beneficio inicial: -1");
      int bOpt = buscar01c (ps, bs, c, 0, c, solParcial, 0, solOptima, -1, cota);
      System.out.println("N�mero de nodos creados durante la b�squeda: " + nodos);
      System.out.print ("Soluci�n �ptima: "); imprimir (solOptima); System.out.println();
      return bOpt;
   }
   private static int buscar01c (int[] ps, int[] bs, int c,
                                 int i, int p,
                                 int[] solParc, int b,
                                 int[] solOpt, int bOpt, int cota) {
      // versi�n de ramificaci�n y poda,
      // tomando como cota superior la suma de todos los beneficios
      nodos++;          
      if (cota>bOpt) {
         if (i==ps.length) {
            if (b>bOpt) {
               bOpt = b;
               for (int j=0; j<ps.length; j++)
                  solOpt[j] = solParc[j];
               System.out.print ("Nuevo m�ximo: "+bOpt+". Estado: ");
               imprimir (solOpt);
            }
         }
         else
            for (int k=0; k<=1; k++) {
               if (k*ps[i]<=p) {
                  solParc[i] = k;
                  int np = p - k*ps[i];
                  int nb = b + k*bs[i];
                  int nCota = cota -(1-k)*bs[i];
                  bOpt = buscar01c (ps, bs, c, i+1, np, solParc, nb, solOpt, bOpt, nCota);
               }
            }
      }
      else {
          System.out.print ("Poda con cota: "+cota+". Estado: ");
          imprimir2 (solParc, i-1); System.out.println();
      }
      return bOpt;
   }

   public static int mochila01_RyP2 (int[] ps, int[] bs, int c) {
      nodos = 1; 
      int[] solParcial = new int[ps.length];
      int[] solOptima = new int[ps.length];
      // se calculan tasas de b/p
      float[] ts = new float[ps.length];
      for (int i=0; i<ps.length; i++)
         ts[i] = (float)bs[i]/ps[i];
      int[] is = new int[ps.length];
      is = ordenarIndices (ts);
      // cota basada en la tasa b/p
      float cota = c*bs[is[0]]/ps[is[0]];
      System.out.println ("Cota inicial: "+cota+". Beneficio inicial: -1");
      int bOpt = buscar01d (ps, bs, c, 0, c, is, solParcial, 0, solOptima, -1, cota);
      System.out.println("N�mero de nodos creados durante la b�squeda: " + nodos);
      System.out.print ("Soluci�n �ptima: "); imprimir (solOptima); System.out.println();
      return bOpt;
   }
   private static int buscar01d (int[] ps, int[] bs, int c,
                                 int i, int p, int[] is,
                                 int[] solParc, int b,
                                 int[] solOpt, int bOpt, float cota) {
      // versi�n de ramificaci�n y poda,
      // tomando como cota superior el rellenar la mochila con la densidad m�xima posible
      nodos++;          
      if ((int)cota>bOpt) {
         if (i==ps.length) {
            if (b>bOpt) {
               bOpt = b;
               for (int j=0; j<ps.length; j++)
                  solOpt[is[j]] = solParc[j];
               System.out.print ("Nuevo m�ximo: "+bOpt+". Estado: ");
               imprimir2 (solParc, ps.length-1); System.out.print ("Decisi�n: ");
               imprimir2 (solOpt, ps.length-1); System.out.println();
            }
         }
         else
            for (int k=0; k<=1; k++) {
               if (k*ps[is[i]]<=p) {
                  solParc[i] = k;
                  int np = p - k*ps[is[i]];
                  int nb = b + k*bs[is[i]];
                  float nCota = (float)nb + ((i==ps.length-1)?0:(np*bs[is[i+1]]/ps[is[i+1]]));
                  bOpt = buscar01d (ps, bs, c, i+1, np, is, solParc, nb, solOpt, bOpt, nCota);
               }
            }
      }
      else {
         System.out.print ("Poda con cota: "+cota+". Estado: ");
         imprimir2 (solParc, i-1); System.out.print ("Decisi�n: ");
         imprimir3 (solParc, i-1, is);
      }
      return bOpt;
   }

   public static int mochila01_RyP3 (int[] ps, int[] bs, int c) {
      // esta versi�n es igual a la anterior pero intercambiando el orden de los candidatos a 1 y 0
      nodos = 1; 
      int[] solParcial = new int[ps.length];
      int[] solOptima = new int[ps.length];
      // se calculan tasas de b/p
      float[] ts = new float[ps.length];
      for (int i=0; i<ps.length; i++)
         ts[i] = (float)bs[i]/ps[i];
      int[] is = new int[ps.length];
      is = ordenarIndices (ts);
      // cota basada en la tasa b/p
      float cota = c*bs[is[0]]/ps[is[0]];
      System.out.println ("Cota inicial: "+cota+". Beneficio inicial: -1");
      int bOpt = buscar01e (ps, bs, c, 0, c, is, solParcial, 0, solOptima, -1, cota);
      System.out.println("N�mero de nodos creados durante la b�squeda: " + nodos);
      System.out.print ("Soluci�n �ptima: "); imprimir (solOptima); System.out.println();
      return bOpt;
   }
   private static int buscar01e (int[] ps, int[] bs, int c,
                                 int i, int p, int[] is,
                                 int[] solParc, int b,
                                 int[] solOpt, int bOpt, float cota) {
      // versi�n de ramificaci�n y poda,
      // tomando como cota superior el rellenar la mochila con la densidad m�xima posible
      nodos++;          
      if ((int)cota>bOpt) {
         if (i==ps.length) {
            if (b>bOpt) {
               bOpt = b;
               for (int j=0; j<ps.length; j++)
                  solOpt[is[j]] = solParc[j];
               System.out.print ("Nuevo m�ximo: "+bOpt+". Estado: ");
               imprimir2 (solParc, ps.length-1); System.out.print ("Decisi�n: ");
               imprimir2 (solOpt, ps.length-1); System.out.println();
            }
         }
         else
            for (int k=1; k>=0; k--) {
               if (k*ps[is[i]]<=p) {
                  solParc[i] = k;
                  int np = p - k*ps[is[i]];
                  int nb = b + k*bs[is[i]];
                  float nCota = (float)nb + ((i==ps.length-1)?0:(np*bs[is[i+1]]/ps[is[i+1]]));
                  bOpt = buscar01e (ps, bs, c, i+1, np, is, solParc, nb, solOpt, bOpt, nCota);
               }
            }
      }
      else {
         System.out.print ("Poda con cota: "+cota+". Estado: ");
         imprimir2 (solParc, i-1); System.out.print ("Decisi�n: ");
         imprimir3 (solParc, i-1, is);
      }
      return bOpt;
   }

   private static int[] ordenarIndices (float[] v1) {
   // se ordena por inserci�n directa seg�n las tasas contenidas en 'v1'
      int[] v2 = new int[v1.length];
      v2[0] = 0;
      for (int i=1; i<v1.length; i++) {
         float aux = v1[i];
         int j;
         for (j=i-1; j>=0 && v1[v2[j]]<aux; j--)
            v2[j+1] = v2[j];
         v2[j+1] = i;
      }
      return v2;
   }

   private static void imprimir (int[] v) {
      for (int i=0; i<v.length; i++)
         System.out.print (v[i]+" ");
      System.out.println();
   }
   private static void imprimir2 (int[] v, int k) {
      for (int i=0; i<=k; i++)
         System.out.print (v[i]+" ");
      for (int i=k+1; i<v.length; i++)
         System.out.print ("- ");
   }
   private static void imprimir3 (int[] v, int k, int[] is) {
      int[] v2 = new int[v.length];
      for (int i=0; i<v.length; i++)
         v2[i] = -1;
      for (int i=0; i<=k; i++)
         v2[is[i]] = v[i];
      for (int i=0; i<v2.length; i++)
         if (v2[i]==-1)
            System.out.print ("- ");
         else
            System.out.print (v[i]+" ");
      System.out.println();
   }
}
