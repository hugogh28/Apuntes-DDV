
/**
 * Write a description of class Permutaciones here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BusquedasBasicas
{
   public static void permutaciones (int[] c) {
      int[] perm = new int[c.length];
      boolean[] libres = new boolean[c.length];
      for (int i=0; i<c.length; i++)
         libres[i] = true;
      perms (c, 0, perm, libres);
   }
   private static void perms (int[] c,
                              int i,
                              int[] solucion,
                              boolean[] xs) {
      if (i==c.length)
         imprimir1 (solucion);
      else
         for (int k=0; k<c.length; k++)
            if (xs[k]) {
               solucion[i] = c[k];
               xs[k] = false;
               perms (c, i+1, solucion, xs);
               xs[k] = true;
            }
   }
   private static void imprimir1 (int[] v) {
      for (int i=0; i<v.length; i++)
         System.out.print (v[i]+" ");
      System.out.println();
   }

   public static void partesConj1 (int[] c) {
      // soluci�n de tama�o fijo
      boolean[] subc = new boolean[c.length];
      partes1 (c, 0, subc);
   }
   private static void partes1 (int[] c,
                                int i,
                                boolean[] subc) {
      if (i==c.length)
         imprimir2 (subc, c);
      else
         for (int k=0; k<=1; k++) {
            subc[i] = (k==1);
            partes1 (c, i+1, subc);
         }
   }
   private static void imprimir2 (boolean[] v, int[] c) {
      for (int i=0; i<v.length; i++)
         System.out.print ((v[i]?c[i]:"-")+" ");
      System.out.println();
   }

   public static void partesConj2 (int[] c) {
      // soluci�n de tama�o variable
      int[] subc = new int[c.length];
      imprimir3 (subc, -1);
      partes2 (c, 0, subc);
   }
   private static void partes2 (int[] c,
                                int i,
                                int[] subc) {
      if (i<c.length)
         for (int k=i; k<c.length; k++) {
            subc[i] = c[k];
            imprimir3 (subc, i);
            partes2 (c, k+1, subc);
         }
   }
   private static void imprimir3 (int[] c, int fin) {
      for (int i=0; i<=fin; i++)
         System.out.print (c[i]+" ");
      System.out.println();
   }

   public static void variaciones (int[] c, int m) {
      int[] var = new int[m];
      boolean[] libres = new boolean[c.length];
      for (int i=0; i<c.length; i++)
         libres[i] = true;
      vars (c, m, 0, var, libres);
   }
   private static void vars (int[] c,
                             int m,
                             int i,
                             int[] solucion,
                             boolean[] libres) {
      if (i==m)
         imprimir1 (solucion);
      else
         for (int k=0; k<c.length; k++) {
            if (libres[k]) {
               solucion[i] = c[k];
               libres[k] = false;
               vars (c, m, i+1, solucion, libres);
               libres[k] = true;
            }
         }
   }

   public static void combinaciones (int[] c, int n) {
      int[] comb = new int[n];
      combs (c, n, 0, 0, comb);
   }
   private static void combs (int[] c,
                              int n,
                              int i,
                              int j,
                              int[] solucion) {
      if (i==n)
         imprimir1 (solucion);
      else
         for (int k=j; k<=c.length+i-n; k++) {
            solucion[i] = c[k];
            combs (c, n, i+1, k+1, solucion);
         }
   }

}
