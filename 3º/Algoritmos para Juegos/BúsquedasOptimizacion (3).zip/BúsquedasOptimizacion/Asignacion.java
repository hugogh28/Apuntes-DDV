
/**
 * Write a description of class Asignaci�n here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Asignacion {

   public static int asignacionBack (int[][] coste) {
      boolean[] tarea = new boolean[coste.length];
      for (int i=0; i<coste.length; i++)
         tarea[i] = true;
      // los vectores de soluci�n contienen la tarea asignada a cada agente
      int[] solParcial = new int[coste.length];
      int[] solOptima = new int[coste.length];
      int cOpt = buscarBack (coste, 0, tarea, solParcial, 0, solOptima, Integer.MAX_VALUE);
      imprimir (solOptima);
      return cOpt;
   }
   
   private static int buscarBack (int[][] coste,
                                  int i, boolean[] tarea,
                                  int[] solParc, int cParc,
                                  int[] solOpt, int cOpt) {
      // versi�n basada en el esquema de la t�cnica de vuelta atr�s para soluci�n �ptima
      // los agentes son los niveles del �rbol de b�squeda y las tareas, los candidatos en cada nodo
      if (i==coste.length) {
          if (cParc<cOpt) {
              cOpt = cParc;
              for (int k=0; k<solParc.length; k++)
                 solOpt[k] = solParc[k];
          }
      }
      else 
          for (int j=0; j<coste.length; j++)
             if (tarea[j]) {
                solParc[i] = j;
                tarea[j] = false;
                cParc += coste[i][j];
                cOpt = buscarBack (coste, i+1, tarea, solParc, cParc, solOpt, cOpt);
                tarea[j] = true;
                cParc -= coste[i][j];
             }
      return cOpt;
   }

   public static int asignacionRyP1 (int[][] coste) {
      boolean[] tarea = new boolean[coste.length];
      for (int i=0; i<coste.length; i++)
         tarea[i] = true;
      int[] solParcial = new int[coste.length];
      int[] solOptima = new int[coste.length];
      int cota = calcularCota1 (coste, tarea, 0, -1);
      System.out.println ("Cota inicial: "+cota+". Coste m�nimo inicial: 0");
      int cOpt = buscarRyP1 (coste, 0, tarea, solParcial, 0, solOptima, Integer.MAX_VALUE, cota);
      imprimir (solOptima);
      return cOpt;
   }
   
   private static int buscarRyP1 (int[][] coste,
                                  int i, boolean[] tarea,
                                  int[] solParc, int cParc,
                                  int[] solOpt, int cOpt, int cota) {
      // versi�n de ramificaci�n y poda, tomando como cota inferior el coste m�nimo de agentes o tareas
      if (cota<cOpt) {
         if (i==coste.length) {
             if (cParc<cOpt) {
                 cOpt = cParc;
                 for (int k=0; k<solParc.length; k++)
                    solOpt[k] = solParc[k];
                 System.out.print ("Nuevo coste m�nimo: "+cOpt+". Estado: ");
                 imprimir (solOpt);
             }
         } else 
             for (int j=0; j<coste.length; j++)
                if (tarea[j]) {
                   solParc[i] = j;
                   tarea[j] = false;
                   cParc += coste[i][j];
                   int nCota = calcularCota1 (coste, tarea, cParc, i);
                   cOpt = buscarRyP1 (coste, i+1, tarea, solParc, cParc, solOpt, cOpt, nCota);
                   tarea[j] = true;
                   cParc -= coste[i][j];
                }
      } else {
          System.out.print ("Poda con cota: "+cota+". Estado: ");
          imprimir2 (solParc, i-1);
      }
      return cOpt;
   }

   private static int calcularCota1 (int[][] coste, boolean[] tarea, int cParcial, int i) {
      int yaAsignado = cParcial;
      // se calculan y acumulan los m�nimos por filas (agentes)
      int suma1 = 0;
      for (int j=i+1; j<coste.length; j++) {
         int min = Integer.MAX_VALUE;
         for (int k=0; k<coste.length; k++)
            if (tarea[k] && coste[j][k]<min)
               min = coste[j][k];
         suma1 += min;
      }
      // se calculan y acumulan los m�nimos por columnas (tareas)
      int suma2 = 0;
      for (int k=0; k<coste.length; k++)
         if (tarea[k]) {
            int min = Integer.MAX_VALUE;
            for (int j=i+1; j<coste.length; j++)
               if (coste[j][k]<min)
                  min = coste[j][k];
            suma2 += min;
         }
      return yaAsignado + Math.max(suma1,suma2);
   }

   public static int asignacionRyP2 (int[][] coste) {
      boolean[] tarea = new boolean[coste.length];
      for (int i=0; i<coste.length; i++)
         tarea[i] = true;
      int[] solParcial = new int[coste.length];
      int[] solOptima = new int[coste.length];
      int[][] matrizDiferencias = new int[coste.length][coste.length];
      for (int i=0; i<coste.length; i++)
         for (int j=0; j<coste.length; j++)
            matrizDiferencias[i][j] = coste[i][j];
      int cota = calcularCota2 (matrizDiferencias, tarea, 0, -1);
      System.out.println ("Cota inicial: "+cota+". Coste m�nimo inicial: 0");
      int cOpt = buscarRyP2 (coste, matrizDiferencias, 0, tarea, solParcial, 0, solOptima, Integer.MAX_VALUE, cota);
      imprimir (solOptima);
      return cOpt;
   }
   
   private static int buscarRyP2 (int[][] coste,
                                  int[][] matriz,
                                  int i, boolean[] tarea,
                                  int[] solParc, int cParc,
                                  int[] solOpt, int cOpt, int cota) {
      // versi�n de ramificaci�n y poda, tomando como cota inferior el coste m�nimo de agentes o tareas
      if (cota<cOpt) {
         if (i==matriz.length) {
             if (cParc<cOpt) {
                 cOpt = cParc;
                 for (int k=0; k<solParc.length; k++)
                    solOpt[k] = solParc[k];
                 System.out.print ("Nuevo coste m�nimo: "+cOpt+". Estado: ");
                 imprimir (solOpt);
             }
         } else {
             int[][] matriz2 = new int[matriz.length][matriz.length];
             for (int j=0; j<matriz.length; j++)
                if (tarea[j]) {
                   solParc[i] = j;
                   tarea[j] = false;
                   cParc += coste[i][j];
                   for (int k=0; k<coste.length; k++)
                      for (int h=0; h<coste.length; h++)
                         matriz2[k][h] = matriz[k][h];
                   int nCota = calcularCota2 (matriz2, tarea, cParc, i);
                   cOpt = buscarRyP2 (coste, matriz2, i+1, tarea, solParc, cParc, solOpt, cOpt, nCota);
                   tarea[j] = true;
                   cParc -= coste[i][j];
                }
             }
      } else {
          System.out.print ("Poda con cota: "+cota+". Estado: ");
          imprimir2 (solParc, i-1);
      }
      return cOpt;
   }

   private static int calcularCota2 (int[][] coste, boolean[] tarea, int cParcial, int i) {
      int yaAsignado = cParcial;
      // se calculan y acumulan los m�nimos por filas (agentes)
      int suma1 = 0;
      for (int j=i+1; j<coste.length; j++) {
         int min = Integer.MAX_VALUE;
         for (int k=0; k<coste.length; k++)
            if (tarea[k] && coste[j][k]<min)
               min = coste[j][k];
         suma1 += min;
         if (min>0)
            for (int k=0; k<coste.length; k++)
               if (tarea[k])
                  coste[j][k] -= min;
      }
      // se calculan y acumulan los m�nimos por columnas (tareas)
      int suma2 = 0;
      for (int k=0; k<coste.length; k++)
         if (tarea[k]) {
            int min = Integer.MAX_VALUE;
            for (int j=i+1; j<coste.length; j++)
               if (coste[j][k]<min)
                  min = coste[j][k];
            suma2 += min;
            if (min>0)
               for (int j=i+1; j<coste.length; j++)
                  coste[j][k] -= min;

         }
      return yaAsignado + suma1 + suma2;
   }

   private static void imprimir (int[] v) {
      for (int i=0; i<v.length; i++)
         System.out.print (v[i]+" ");
      System.out.println();
   }
   private static void imprimir2 (int[] v, int k) {
      for (int i=0; i<=k; i++)
         System.out.print (v[i]+" ");
      System.out.println();
   }

}
