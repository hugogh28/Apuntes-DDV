
/**
 * Write a description of class CicloHamiltoniano here.
 * 
 * @author (�ngel Vel�zquez Iturbide, Departamento de Inform�tica y Estad�stica, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos Avanzados, Grados en Ingenier�a Inform�tica e Ingenier�a de Computadores
 * @version (Curso 2023-24)
 */
public class CicloHamiltoniano
{ 
   public static int cicloHamiltonianoBack (int[][] grafo) {
      boolean[] libre = new boolean[grafo.length];
      libre[0] = false; 
      for (int i=1; i<grafo.length; i++) 
         libre[i] = true;
      int[] caminoParc = new int[grafo.length+1]; //podr�an suprimirse los nodos primero y �ltimo, ya que son el nodo 0
      caminoParc[0] = 0;
      int[] caminoOpt = new int[grafo.length+1]; //podr�an suprimirse los nodos primero y �ltimo, ya que son el nodo 0
      int longitud = buscarH (grafo, 1, libre, caminoParc, 0, caminoOpt, Integer.MAX_VALUE);
      imprimir(caminoOpt);
      return longitud;
   }
   private static int buscarH (int[][] grafo,
                               int i, boolean[] libre,
                               int[] caminoParc, int d,
                               int[] caminoOpt, int dOpt) {
      if (i==grafo.length) {
         if (grafo[caminoParc[i-1]][0] < Integer.MAX_VALUE) {
            caminoParc[i] = 0;
            d += grafo[caminoParc[i-1]][0];
            if (d<dOpt) {
               dOpt = d;
               for (int k=0; k<=grafo.length; k++)
                  caminoOpt[k] = caminoParc[k];
            }
         }  
      } else
         for (int j=1; j<grafo.length; j++)
            if ((libre[j]) && (grafo[caminoParc[i-1]][j]<Integer.MAX_VALUE)){
               caminoParc[i] = j;
               libre[j] = false;
               d += grafo[caminoParc[i-1]][j];
               dOpt = buscarH (grafo, i+1, libre, caminoParc, d, caminoOpt, dOpt);
               libre[j] = true;
               d -= grafo[caminoParc[i-1]][j];       
            }
      return dOpt;   
    }

   public static int cicloHamiltonianoRyP1 (int[][] grafo) {
      boolean[] libre = new boolean[grafo.length];
      libre[0] = false; 
      for (int i=0; i<grafo.length; i++) 
         libre[i] = true;
      int[] caminoParc = new int[grafo.length+1]; //podr�an suprimirse los nodos primero y �ltimo, ya que son el nodo 0
      caminoParc[0] = 0;
      int[] caminoOpt = new int[grafo.length+1]; //podr�an suprimirse los nodos primero y �ltimo, ya que son el nodo 0
      int[][] masCercanos = new int[grafo.length][2];
      masCercanos = calcularParesNodosMasCercanos (grafo);
      float cota = calcularCota1 (grafo, masCercanos);
      int longitud = buscarHRyP1 (grafo, 1, libre, caminoParc, 0, caminoOpt, Integer.MAX_VALUE, masCercanos, cota);
      imprimir(caminoOpt);
      return longitud;
   }
   private static int buscarHRyP1 (int[][] grafo,
                                   int i, boolean[] libre,
                                   int[] caminoParc, int d,
                                   int[] caminoOpt, int dOpt,
                                   int[][] masCercanos, float cota) {
      if (cota<dOpt) {
         if (i==grafo.length) {
            if (grafo[caminoParc[grafo.length-1]][0]<Integer.MAX_VALUE) {
               caminoParc[grafo.length] = 0;
               d += grafo[caminoParc[grafo.length-1]][0];
               if (d<dOpt) {
                  dOpt = d;
                  for (int k=0; k<=grafo.length; k++)
                     caminoOpt[k] = caminoParc[k];
               }
            }  
         } else
            for (int j=1; j<grafo.length; j++)
               if ((libre[j]) && (grafo[caminoParc[i-1]][j]<Integer.MAX_VALUE)){
                  caminoParc[i] = j;
                  libre[j] = false;
                  d += grafo[caminoParc[i-1]][j];
                  float nCota = actualizarCota1 (cota, i, j, caminoParc, masCercanos, grafo);
                  dOpt = buscarHRyP1 (grafo, i+1, libre, caminoParc, d, caminoOpt, dOpt, masCercanos, nCota);
                  libre[j] = true;
                  d -= grafo[caminoParc[i-1]][j];       
               }
      }
      return dOpt;   
    }

   private static int[][] calcularParesNodosMasCercanos (int[][] grafo) {
      int[][] masCercanos  = new int[grafo.length][2];
      for (int i=0; i<grafo.length; i++) {
         int nodo0 = -1; int nodo1 = -1;
         int menor0 = Integer.MAX_VALUE;
         int menor1 = Integer.MAX_VALUE;
         for (int j=0; j<grafo.length; j++)
            if ((i!=j) && grafo[i][j]!=Integer.MAX_VALUE)
               if (grafo[i][j]<menor0) {
                  nodo1 = nodo0;
                  menor1 = menor0;
                  nodo0 = j;
                  menor0 = grafo[i][j];
               } else if (grafo[i][j]<menor1) {
                  nodo1 = j;
                  menor1 = grafo[i][j];
               }
         masCercanos[i][0] = nodo0;
         masCercanos[i][1] = nodo1;
      }
      return masCercanos;
   }
   
   private static float calcularCota1 (int[][] grafo, int[][] masCercanos) {
      float cota = 0;
      for (int i=0; i<grafo.length; i++)
         cota += grafo[i][masCercanos[i][0]] + grafo[i][masCercanos[i][1]];
      return cota/2;
   }
   
   private static float actualizarCota1 (float cota, int k, int j, int[] camino, int[][] masCercanos, int[][] grafo) {
      if (k==1) {
         float dif;
         if ((j==masCercanos[0][0]) || (j==masCercanos[0][1]))
            dif = 0;
         else
            dif = grafo[0][j]-grafo[0][masCercanos[0][1]];
         return cota+dif;
      } else {
         int i = camino[k-1];
         float dif1;
         if ((j==masCercanos[i][0]) || (j==masCercanos[i][1]))
            dif1 = 0;
         else if (grafo[camino[k-2]][i]==grafo[i][masCercanos[i][1]])
            dif1 = grafo[i][j]-grafo[i][masCercanos[i][0]];
         else
            dif1 = grafo[i][j]-grafo[i][masCercanos[i][1]];
         float dif2;
         if ((grafo[i][j]==grafo[j][masCercanos[j][0]]) || (grafo[i][j]==grafo[j][masCercanos[j][1]]))
            dif2 = 0;
         else
            dif2 = grafo[i][j]-grafo[j][masCercanos[j][1]];
         return cota + (dif1+dif2)/2;
      }
   }
      
   public static int cicloHamiltonianoRyP2 (int[][] grafo) {
      boolean[] libre = new boolean[grafo.length];
      libre[0] = false; 
      for (int i=0; i<grafo.length; i++) 
         libre[i] = true;
      int[] caminoParc = new int[grafo.length+1]; //podr�an suprimirse los nodos primero y �ltimo, ya que son el nodo 0
      caminoParc[0] = 0;
      int[] caminoOpt = new int[grafo.length+1]; //podr�an suprimirse los nodos primero y �ltimo, ya que son el nodo 0
      int[][] matrizCostes = new int[grafo.length][grafo.length];
      for (int i=0; i<grafo.length; i++)
         for (int j=0; j<grafo.length; j++)
            matrizCostes[i][j] = grafo[i][j];
      int cota = reducirMatriz (matrizCostes);
      int longitud = buscarHRyP2 (grafo, matrizCostes, 1, libre, caminoParc, 0, caminoOpt, Integer.MAX_VALUE, cota);
      imprimir(caminoOpt);
      return longitud;
   }
   private static int buscarHRyP2 (int[][] grafo,
                                   int[][] matriz,
                                   int i, boolean[] libre,
                                   int[] caminoParc, int d,
                                   int[] caminoOpt, int dOpt,
                                   int cota) {
      if (cota<dOpt) {
         if (i==grafo.length) {
            if (grafo[caminoParc[grafo.length-1]][0]<Integer.MAX_VALUE) {
               caminoParc[grafo.length] = 0;
               d += grafo[caminoParc[grafo.length-1]][0];
               if (d<dOpt) {
                  dOpt = d;
                  for (int k=0; k<=grafo.length; k++)
                     caminoOpt[k] = caminoParc[k];
               }
            }  
         } else {
            int[][] matriz2 = new int[grafo.length][grafo.length];
            for (int j=1; j<grafo.length; j++)
               if ((libre[j]) && (grafo[caminoParc[i-1]][j]<Integer.MAX_VALUE)){
                  caminoParc[i] = j;
                  libre[j] = false;
                  d += grafo[caminoParc[i-1]][j];
                  for (int k=0; k<grafo.length; k++)
                     for (int h=0; h<grafo.length; h++)
                        matriz2[k][h] = matriz[k][h];
                  int nCota = actualizarCota2 (cota, matriz2, caminoParc[i-1], j, grafo);
                  dOpt = buscarHRyP2 (grafo, matriz2, i+1, libre, caminoParc, d, caminoOpt, dOpt, nCota);
                  libre[j] = true;
                  d -= grafo[caminoParc[i-1]][j];       
               }
         }
      }
      return dOpt;   
    }

   private static int reducirMatriz (int[][] matriz) {
      int cota = 0;
      // se calculan y acumulan los m�nimos por filas (agentes)
      for (int i=0; i<matriz.length; i++) {
         int min = Integer.MAX_VALUE;
         for (int j=0; j<matriz.length; j++)
            if (matriz[i][j]<min)
               min = matriz[i][j];
         if ((min>0) && (min<Integer.MAX_VALUE)) {
            cota += min;
            for (int j=0; j<matriz.length; j++)
               if (matriz[i][j]<Integer.MAX_VALUE)
                  matriz[i][j] -= min;
         }
      }
      // se calculan y acumulan los m�nimos por columnas (tareas)
      for (int j=0; j<matriz.length; j++) {
         int min = Integer.MAX_VALUE;
         for (int i=0; i<matriz.length; i++)
            if (matriz[i][j]<min)
               min = matriz[i][j];
         if ((min>0) && (min<Integer.MAX_VALUE)) {
            cota += min;
            for (int i=0; i<matriz.length; i++)
               if (matriz[i][j]<Integer.MAX_VALUE)
                  matriz[i][j] -= min;
         }
      }
      return cota;
   }

   private static int actualizarCota2 (int cota, int[][] matriz, int i, int j, int[][] grafo) {
      int nCota = cota + matriz[i][j];
      for (int k=0; k<grafo.length; k++)
         matriz[i][k] = Integer.MAX_VALUE;
      for (int k=0; k<grafo.length; k++)
         matriz[k][j] = Integer.MAX_VALUE;
      matriz[j][i] = Integer.MAX_VALUE;
      nCota += reducirMatriz (matriz);
      return nCota;
   }
      
   private static void imprimir (int[] v) {
      for (int i=0; i<v.length; i++)
         System.out.print (v[i]+" ");
      System.out.println();
   }

}