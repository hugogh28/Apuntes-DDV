
/**
 * Write a description of class LlenadoCajas here.
 * 
 * @author (�ngel Vel�zquez Iturbide, Departamento de Inform�tica y Estad�stica, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos Avanzados, Grado en Ingenier�a Inform�tica
 * @version (Cursos 2014-15, 2016-17, 2024-25)
 */
public class LlenadoCajas
{
   static int nodos;
   
   public static int masObjetosBack (int[] ps, int n, int c) {
      System.out.print ("Objetos de pesos: "); imprimir (ps);
      System.out.print (" y " + n);
      System.out.print (" cajas de capacidad: " + c); System.out.println();
      int[] cajas = new int[n];
      for (int i=0; i<n; i++)
         cajas[i] = c;
      int[] donde = new int[ps.length];
      for (int i=0; i<ps.length; i++)
         donde[i] = -1;
      int[] dondeOpt = new int[ps.length];
      int num = buscarObjetosBack (ps, n, c, 0, 0, cajas, donde, -1, dondeOpt);
      System.out.println ("Soluci�n �ptima: " + num + " objetos"); 
      imprimirCajas (n, dondeOpt, ps); System.out.println ();
      return num;       
   }

   private static int buscarObjetosBack (int[] ps, int n, int c,
                                         int i,
                                         int nObj, int[] cajas, int[] donde,
                                         int nOpt, int[] dondeOpt) {
      // versi�n basada en el esquema de la t�cnica de vuelta atr�s para soluci�n �ptima
      if (i==ps.length) {
         if (nObj>nOpt) {
            nOpt = nObj;
            for (int k=0; k<ps.length; k++)
               dondeOpt[k] = donde[k];
         }
      }
      else {
         // opci�n de no meter el objeto en ninguna caja
         nOpt = buscarObjetosBack (ps, n, c, i+1, nObj, cajas, donde, nOpt, dondeOpt);
         // opciones de meter el objeto en alguna caja
         for (int j=0; j<n; j++)
            if (ps[i]<=cajas[j]) {
               nObj++;
               donde[i] = j;
               cajas[j] -= ps[i];
               nOpt = buscarObjetosBack (ps, n, c, i+1, nObj, cajas, donde, nOpt, dondeOpt);
               nObj--;
               donde[i] = -1;
               cajas[j] += ps[i];
            }
      }
      return nOpt;
   }

   public static int masObjetosRyP (int[] ps, int n, int c) {
      System.out.print ("Objetos de pesos: "); imprimir (ps);
      System.out.print (" y " + n);
      System.out.print (" cajas de capacidad: " + c); System.out.println();
      int[] cajas = new int[n];
      for (int i=0; i<n; i++)
         cajas[i] = c;
      int[] donde = new int[ps.length];
      for (int i=0; i<ps.length; i++)
         donde[i] = -1;
      int[] dondeOpt = new int[ps.length];
      int cota = ps.length;
      int num = buscarObjetosRyP (ps, n, c, 0, cota, 0, cajas, donde, -1, dondeOpt);
      System.out.println ("Soluci�n �ptima: " + num + " objetos"); 
      imprimirCajas (n, dondeOpt, ps); System.out.println ();
      return num;       
   }

   private static int buscarObjetosRyP (int[] ps, int n, int c,
                                        int i, int cota,
                                        int nObj, int[] cajas, int[] donde,
                                        int nOpt, int[] dondeOpt) {
      // versi�n basada en el esquema de la t�cnica de vuelta atr�s para soluci�n �ptima
      // opci�n de no meter el objeto en ninguna caja
      if (cota>nOpt) {
         if (i==ps.length) {
            if (nObj>nOpt) {
               nOpt = nObj;
               for (int k=0; k<ps.length; k++)
                  dondeOpt[k] = donde[k];
            }
         }
         else {
            // opci�n de no meter el objeto en ninguna caja
            cota--;
            nOpt = buscarObjetosRyP (ps, n, c, i+1, cota, nObj, cajas, donde, nOpt, dondeOpt);
            // opciones de meter el objeto en alguna caja
            cota++;
            for (int j=0; j<n; j++)
               if (ps[i]<=cajas[j]) {
                  nObj++;
                  donde[i] = j;
                  cajas[j] -= ps[i];
                  nOpt = buscarObjetosRyP (ps, n, c, i+1, cota, nObj, cajas, donde, nOpt, dondeOpt);
                  nObj--;
                  donde[i] = -1;
                  cajas[j] += ps[i];
               }
         }
      }
      return nOpt;
   }

   public static int menosCajasBack (int[] ps, int c) {
      System.out.print ("Objetos de pesos: "); imprimir (ps);
      System.out.print (" y cajas de capacidad: " + c); System.out.println();
      nodos = 1;
      int[] libre = new int[ps.length];
      libre[0] = c-ps[0];
      for (int i=1; i<ps.length; i++)
         libre[i] = c;
      int[] donde = new int[ps.length];
      donde[0] = 0;
      int[] dondeOpt = new int[ps.length];
      int num = buscarCajasBack (ps, c, 1, libre, 1, donde, ps.length, dondeOpt);
      System.out.println ("Soluci�n �ptima: " + num + " cajas"); 
      imprimirCajas (num, dondeOpt, ps);
      System.out.println("N�mero de nodos creados durante la b�squeda: " + nodos); System.out.println ();
      return num;
   }
   
   private static int buscarCajasBack (int[] ps, int c,
                                       int i, int[] libre,
                                       int n, int[] donde,
                                       int nOpt, int[] dondeOpt) {
      // versi�n basada en el esquema de la t�cnica de vuelta atr�s para soluci�n �ptima
      nodos++;
      if (i==ps.length) {
         if (n<nOpt) {
            nOpt = n;
            for (int k=0; k<ps.length; k++)
               dondeOpt[k] = donde[k];
            System.out.print ("Nuevo m�nimo: "+nOpt+". Estado: ");
            imprimir (dondeOpt); System.out.println ();
         }
      }
      else 
         for (int j=0; j<=n; j++)
            if (ps[i]<=libre[j]) {
               donde[i] = j;
               libre[j] -= ps[i];
               int nn = (j<n)?n:n+1;
               nOpt = buscarCajasBack (ps, c, i+1, libre, nn, donde, nOpt, dondeOpt);
               libre [j] += ps[i];
            }
      return nOpt;
   }

   public static int menosCajasRyP (int[] ps, int c) {
      System.out.print ("Objetos de pesos: "); imprimir (ps);
      System.out.print (" y cajas de capacidad: " + c); System.out.println();
      nodos = 1;
      int[] libre = new int[ps.length];
      libre[0] = c-ps[0];
      for (int i=1; i<ps.length; i++)
         libre[i] = c;
      int[] donde = new int[ps.length];
      donde[0] = 0;
      int[] dondeOpt = new int[ps.length];
      // cota como suma de cajas usadas m�s n�mero m�nimo de cajas necesarias para el resto de objetos
      int restante = c - ps[0];
      int[] psAcum = new int[ps.length];
      psAcum[psAcum.length-1] = ps[ps.length-1];
      for (int i=ps.length-2; i>=0; i--)
         psAcum[i] = ps[i]+psAcum[i+1];
      int cota = (int) Math.ceil((float)(psAcum[0])/(float)c);
      System.out.println ("Cota inicial: "+cota+". N�m. inicial de cajas: "+ps.length);
      int num = buscarCajasRyP (ps, c, 1, libre, psAcum, 1, donde, restante, cota, ps.length, dondeOpt);
      System.out.println ("Soluci�n �ptima: " + num + " cajas"); 
      imprimirCajas (num, dondeOpt, ps);
      System.out.println("N�mero de nodos creados durante la b�squeda: " + nodos); System.out.println ();
      return num;
   }
   
   private static int buscarCajasRyP (int[] ps, int c,
                                      int i, int[] libre, int[] psAcum,
                                      int n, int[] donde, int restante, int cota,
                                      int nOpt, int[] dondeOpt) {
      // versi�n basada en el esquema de la t�cnica de ramificaci�n y poda
      nodos++;
      if (cota<nOpt) {
         if (i==ps.length) {
            if (n<nOpt) {
               nOpt = n;
               for (int k=0; k<ps.length; k++)
                  dondeOpt[k] = donde[k];
               System.out.print ("Nuevo m�nimo: "+nOpt+". Estado: ");
               imprimir (dondeOpt); System.out.println ();
            }
         } else {
            for (int j=0; j<=n; j++)
               if (ps[i]<=libre[j]) {
                  donde[i] = j;
                  libre[j] -= ps[i];
                  int nn, nRestante;
                  if (j<n) {
                     nn = n;
                     nRestante = restante - ps[i];
                  } else {
                     nn = n+1;
                     nRestante = restante + c-ps[i];
                  }
                  int nCota = nn + ((i==ps.length-1)?0:(int)Math.ceil((float)((psAcum[i+1]-nRestante)/c)));
                  nOpt = buscarCajasRyP (ps, c, i+1, libre, psAcum, nn, donde, nRestante, nCota, nOpt, dondeOpt);
                  libre [j] += ps[i];
               }
         }
      } else {
         System.out.print ("Poda con cota: "+cota+". Estado: ");
         imprimir2 (donde, i-1); System.out.println();
      }
      return nOpt;
   }

   private static void imprimirCajas (int x, int[] v, int[] ps) {
      for (int i=0; i<x; i++) {
         System.out.print ("Caja n�m. "+i+" contiene los objetos de pesos (�ndices): ");
         for (int j=0; j<ps.length; j++)
            if (v[j]==i)
               System.out.print (ps[j] + "(" + j + ") ");
         System.out.println ();
      }
   }

   private static void imprimir (int[] v) {
      for (int i=0; i<v.length; i++)
         System.out.print (v[i]+" ");
   }
   private static void imprimir2 (int[] v, int k) {
      for (int i=0; i<=k; i++)
         System.out.print (v[i]+" ");
      for (int i=k+1; i<v.length; i++)
         System.out.print ("- ");
   }
}