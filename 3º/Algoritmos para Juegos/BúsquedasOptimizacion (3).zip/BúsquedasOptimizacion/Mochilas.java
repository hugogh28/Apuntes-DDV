
/**
 * Write a description of class MochilasOtros here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Mochilas
{
   public static int maxPeso (int[] ps, int c) {
      int[] solParcial = new int[ps.length];
      int[] solOptima = new int[ps.length];
      int pOpt = buscarMaxPeso (ps, c, 0, solParcial, 0, solOptima, -1);
      imprimir (solOptima);
      return pOpt;
   }
   private static int buscarMaxPeso (int[] ps, int c,
                                     int i,
                                     int[] solParcial, int pParcial,
                                     int[] solMax, int pMax) {
      if (i==ps.length) {
         if (pParcial>pMax) {
            pMax = pParcial;
            for (int j=0; j<ps.length; j++)
               solMax[j] = solParcial[j];
         }
      }
      else
         for (int k=0; k<=1; k++) {
            if (k*ps[i]<=c-pParcial) {
               solParcial[i] = k;
               pParcial += k*ps[i];
               pMax = buscarMaxPeso (ps, c, i+1, solParcial, pParcial, solMax, pMax);
               //int pParcial -= k*ps[i]; innecesaria porque en la primera iteraci�n k==0
            }
         }
      return pMax;
   }
   
   public static int maxNum2 (int[] ps, int c1, int c2) {
      int[] solParcial = new int[ps.length];
      int[] n1n2Parcial = new int[] {0,0};
      int[] p1p2Parcial = new int[] {c1,c2};
      int[] solOptima = new int[ps.length];
      int[] n1n2Optimos = new int[] {-1,-1};
      int nOpt = buscarMaxNum2 (ps, c1, c2, 0, solParcial, n1n2Parcial, p1p2Parcial, solOptima, n1n2Optimos);
      imprimir (solOptima);
      return nOpt;
   }
   private static int buscarMaxNum2 (int[] ps, int c1, int c2,
                                     int i,
                                     int[] solParcial, int[] n1n2Parcial, int[] p1p2Parcial,
                                     int[] solOptima, int[] n1n2Optimos) {
      if (i==ps.length) {
         if (n1n2Parcial[0]+n1n2Parcial[1]>n1n2Optimos[0]+n1n2Optimos[1]) {
            n1n2Optimos[0] = n1n2Parcial[0];
            n1n2Optimos[1] = n1n2Parcial[1];
            for (int j=0; j<ps.length; j++)
               solOptima[j] = solParcial[j];
         }
      }
      else {
         for (int k=0; k<=2; k++) {
            if ((k==0) || ((k==1)&&(ps[i]<=p1p2Parcial[0])) || ((k==2)&&(ps[i]<=p1p2Parcial[1]))) {
               solParcial[i] = k;
               if (k==1) {
                  n1n2Parcial[0]++;
                  p1p2Parcial[0] -= ps[i];
               }
               else if (k==2) {
                  n1n2Parcial[1]++;
                  p1p2Parcial[1] -= ps[i];
               }
               int[] n1n2 = new int[] {n1n2Parcial[0], n1n2Parcial[1]};
               int nMax = buscarMaxNum2 (ps, c1, c2, i+1, solParcial, n1n2, p1p2Parcial, solOptima, n1n2Optimos);
               if (k==1) {
                  n1n2Parcial[0]--;
                  p1p2Parcial[0] += ps[i];
               }
               else if (k==2) {
                  n1n2Parcial[1]++;
                  p1p2Parcial[1] += ps[i];
               }
            }
         }
      }
      return n1n2Optimos[0]+n1n2Optimos[1];
   }
   
   private static void imprimir (int[] v) {
      for (int i=0; i<v.length; i++)
         System.out.print (v[i]+" ");
      System.out.println();
   }
}
