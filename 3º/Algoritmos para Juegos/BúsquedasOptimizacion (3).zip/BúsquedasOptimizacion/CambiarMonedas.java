
/**
 * Write a description of class CambiarMonedas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CambiarMonedas
{
   static int[] unidades = {200, 100, 50, 20, 10, 5, 2, 1};
   //static int[] unidades = {7, 5, 1};

   public static int cambiarMonedas1 (int total) {
      int[] cambioParcial = new int[unidades.length];
      int[] cambioOpt = new int[unidades.length];
      int monedas = cambiarMonedas (0, total, cambioParcial, 0, cambioOpt, total+1);
      imprimir (unidades);
      imprimir (cambioOpt);
      return (monedas);
   }

   private static int cambiarMonedas (int i, int resto,
                                      int[] cambioParcial, int monedasParcial,
                                      int[] cambioOpt, int monedasOpt) {
      if (i==unidades.length) {
         if ((resto==0) && (monedasParcial<monedasOpt)) {
            monedasOpt = monedasParcial;
            for (int j=0; j<unidades.length; j++)
               cambioOpt[j] = cambioParcial[j];
         }
      }
      else {
         int maxUnidad = resto / unidades[i];
         for (int k=0; k<=maxUnidad; k++) {
            monedasParcial += k;
            cambioParcial[i] = k;
            resto -= k*unidades[i];
            monedasOpt = cambiarMonedas (i+1, resto, cambioParcial, monedasParcial, cambioOpt, monedasOpt);
            monedasParcial -= k;
            resto += k*unidades[i];
         }
      }
      return monedasOpt;
   }

  private static void imprimir (int[] v) {
      for (int i=0; i<v.length; i++)
         System.out.print ((v[i]<10?("  "+v[i]):(v[i]<100?" "+v[i]:v[i]))+" ");
      System.out.println();
   }
}
