
/**
 * Write a description of class EquilibradoCarga here.
 * 
 * @author (�ngel Vel�zquez Iturbide, Departamento de Inform�tica y Estad�stica, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos Avanzados, Grado en Ingenier�a Inform�tica
 * @version (Curso 2016-17)
 */
public class EquilibradoCarga
{
   public static int equilibrarCargas (int m, int[] ts) {
      int[] cargasParcial = new int[m];
      int[] cargasOptima  = new int[m];
      for (int i=0; i<m; i++)
         cargasOptima[i] = Integer.MAX_VALUE;
      ecBack (0, m, ts, cargasParcial, cargasOptima);
      System.out.println ("Dados " + m + " procesadores y " + "las siguientes tareas:");
      imprimir(ts);
      System.out.println ("el reparto m�s equilibrado da una carga m�xima de: " + maximo(cargasOptima));
      System.out.println ("quedando los procesadores con la siguiente carga:");
      imprimir(cargasOptima);
      return (maximo(cargasOptima));
   }

   private static void ecBack (int i,
                               int m,
                               int[] ts,
                               int[] csParcial,
                               int[] csOptima) {
      if (i==ts.length) {
         int cargaParcial = maximo(csParcial);
         int cargaOptima  = maximo(csOptima);
         if (cargaParcial<cargaOptima)
            for (int j=0; j<m; j++)
               csOptima[j] = csParcial[j];
      } else
         for (int k=0; k<m; k++) {
            csParcial[k] += ts[i];
            ecBack (i+1, m, ts, csParcial, csOptima);
            csParcial[k] -= ts[i];
         }
   }

   private static int maximo (int[] v) {
      int max = Integer.MIN_VALUE;
      for (int i=0; i<v.length; i++)
         if (v[i]>max)
            max = v[i];
      return max;
   }

   private static void imprimir (int[] v) {
      for (int i=0; i<v.length; i++)
         System.out.print (v[i]+" ");
      System.out.println();
   }

}
