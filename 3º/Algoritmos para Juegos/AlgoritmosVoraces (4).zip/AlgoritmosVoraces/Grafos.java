
/**
 * Write a description of class Grafos here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Grafos
{
   public static int[] Dijkstra1 (int[][] grafo, int origen) {
      // calcula las longitudes de los caminos m�nimos
      // conjunto de candidatos, con todos los nodos salvo el origen
      boolean[] candidatos = new boolean[grafo.length];
      for (int i=0; i<candidatos.length; i++)
         candidatos[i] = true;
      candidatos[origen] = false;
      // distancias inicializadas como vienen dadas en el grafo
      int[] distancias = new int[grafo.length];
      for (int i=0; i<distancias.length; i++)
         distancias[i] = grafo[origen][i];
      distancias[origen] = 0;
      // iteraci�n para todos los candidatos
      for (int i=0; i<grafo.length-1; i++) {
         // se busca un primer candidato
         int j;
         for (j=0; j<candidatos.length && !candidatos[j]; j++) {}
         int menor = j;
         // se busca el candidato m�s cercano al origen
         for (; j<candidatos.length; j++) {
            if (candidatos[j] && distancias[j]<distancias[menor])
               menor = j;
         }
         candidatos[menor] = false;
         // se actualizan las distancias m�nimas que pasan por el nuevo candidato
         for (j=0; j<candidatos.length; j++) {
            if (candidatos[j])
               distancias[j] = min (distancias[j], distancias[menor]+grafo[menor][j]);
         }
      }
      return distancias;
   }
   
   public static int[] Dijkstra2 (int[][] grafo, int origen) {
      // calcula las longitudes de los caminos m�nimos y los propios caminos m�nimos
      // conjunto de candidatos, con todos los nodos salvo el origen
      boolean[] candidatos = new boolean[grafo.length];
      for (int i=0; i<candidatos.length; i++)
         candidatos[i] = true;
      candidatos[origen] = false;
      // distancias inicializadas como vienen dadas en el grafo, y predecesores
      int[] distancias = new int[grafo.length];
      int[] predecesores = new int[grafo.length];
      for (int i=0; i<distancias.length; i++) {
         distancias[i] = grafo[origen][i];
         predecesores[i] = grafo[origen][i]<1000?origen:0; /*valor tomado como infinito*/
      }
      distancias[origen] = 0;
      predecesores[origen] = 0;
      // iteraci�n para cada candidato
      for (int i=0; i<grafo.length-1; i++) {
         // se busca un primer candidato
         int j;
         for (j=0; (j<candidatos.length) && !(candidatos[j]); j++) {}
         int menor = j;
         // se busca el candidato m�s cercano al origen
         for (; j<candidatos.length; j++) {
            if ((candidatos[j]) && (distancias[j]<distancias[menor]))
               menor = j;
         }
         candidatos[menor] = false;
         // se actualizan las distancias m�nimas que pasan por el nuevo candidato
         for (j=0; j<candidatos.length; j++) {
            if (candidatos[j])
               if (distancias[menor]+grafo[menor][j]<distancias[j]) {
                   distancias[j] = distancias[menor]+grafo[menor][j];
                   predecesores[j] = menor;
               }
         }
      }
      imprimirCaminos (predecesores, origen, distancias);
      return distancias;
   }
   
   private static int min (int m, int n) {
      return ((m<n)?m:n);
   }
   
   private static void imprimirCaminos (int[] preds, int origen, int[] distancias) {
      for (int i=0; i<preds.length; i++) {
         System.out.print ("Nodo "+i+" : camino = ");
         if (distancias[i]==1000) /*valor tomado como infinito*/
            System.out.print ("-");
         else
            imprimirCamino(preds,origen,i);
         System.out.println ();
      }
   }
   
   private static void imprimirCamino (int[] preds, int origen, int j) {
      if (j!=origen)
         imprimirCamino (preds,origen,preds[j]);
      System.out.print (j+" ");
   }

   public static int Prim (int[][] grafo) {
      // calcula el coste m�nimo y los arcos correspondientes
      // vectores que representan los arcos del MST (origen y destino)
      int[] orig = new int[grafo.length-1];
      int[] dest = new int[grafo.length-1];
      // representaci�n impl�cita del subconjunto S de nodos que forman el MST
      // masProx[i] contiene el nodo de S m�s cercano al nodo i
      // distMin[i] = -1 si el nodo i pertenece a S
      //            = si no, distancia entre i y masProx[i]
      int[] masProx = new int[grafo.length];
      int[] distMin = new int[grafo.length];
      // inicializaci�n de vectores auxiliares, suponiendo que el MST contiene al nodo cero
      for (int i=1; i<grafo.length; i++) {
         masProx[i] = 0;
         distMin[i] = grafo[i][0];
      }
      // bucle voraz
      for (int i=0; i<grafo.length-1; i++) {
         // se selecciona nodo m�s cercano al MST ya formado
         int min = 1000;
         int k = 0;
         for (int j=1; j<grafo.length; j++)
            if ((0<=distMin[j]) && (distMin[j]<min)) {
               min = distMin[j];
               k = j;
            }
         // se a�ade el arco al nodo k al MST
         orig[i] = masProx[k];
         dest[i] = k;
         distMin[k] = -1;
         // se actualizan las distancias m�nimas al resto de nodos
         for (int j=1; j<grafo.length; j++)
            if (grafo[j][k]<distMin[j]) {
               distMin[j] = grafo[j][k];
               masProx[j] = k;
            }
      }
      int coste = 0;
      for (int i=0; i<grafo.length-1; i++)
         coste += grafo[orig[i]][dest[i]];
      imprimirArcos (orig, dest);
      return coste;
   }
   
   private static void imprimirArcos (int[] orig, int[] dest) {
      for (int i=0; i<orig.length; i++)
         System.out.println ("Arco "+i+": ("+orig[i]+","+dest[i]+")");
   }
      
}