
/**
 * Write a description of class OrdenarIndices here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class OrdenarIndices
{
   // coincide con el problema de almacenamento �ptimo en cintas
   // o del tiempo de espera en el sistema;
   // calcula el orden �ptimo pero no el valor �ptimo
   // en esta implementaci�n se usa ordenaci�n creciente por inserci�n
   
   public static void ordenarEnVector (int[] v) {
      for (int i=1; i<v.length; i++) {
         int aux = v[i];
         int j;
         for (j=i-1; j>=0 && v[j]>aux; j--)
            v[j+1] = v[j];
         v[j+1] = aux;
      }
   }

   public static int[] ordenarEnIndices (int[] v) {
      int[] v2 = new int[v.length];
      v2[0] = 0;
      for (int i=1; i<v.length; i++) {
         int aux = v[i];
         int j;
         for (j=i-1; j>=0 && v[v2[j]]>aux; j--)
            v2[j+1] = v2[j];
         v2[j+1] = i;
      }
      return v2;
   }

}
