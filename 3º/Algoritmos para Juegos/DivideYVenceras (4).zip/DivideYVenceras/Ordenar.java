
/**
 * @author (�ngel Vel�zquez) 
 * @version (Octubre de 2004)
 */
public class Ordenar
{
   // Los 3 algoritmos de ordenaci�n por mezcla difieren en el uso de arrays para la mezcla
   public static void mergeSort1 (int[] v) {
      ordenarPorMezcla1 (v, 0, v.length-1);
   }
   private static void ordenarPorMezcla1 (int[] v, int inf, int sup) {
      if (inf<sup) {
         int medio = (inf+sup)/2;
         ordenarPorMezcla1 (v, inf, medio);
         ordenarPorMezcla1 (v, medio+1, sup);
         mezclar1 (v, inf, medio, sup);
      }
   }
   private static void mezclar1 (int[] v, int inf, int medio, int sup) {
      int[] vAux = new int[v.length]; //vector auxiliar de longitud n
      int i1 = inf;
      int i2 = medio+1;
      int j = inf;
      while (i1<=medio && i2<=sup) {
         if (v[i1]<v[i2]) {
            vAux[j] = v[i1];
            i1++;
         }
         else {
            vAux[j] = v[i2];
            i2++;
         }
         j++;
      }
      for (int i=i1; i<=medio; i++) {
         vAux[j] = v[i];
         j++;
      }
      for (int i=i2; i<=sup; i++) {
         vAux[j] = v[i];
         j++;
      }
      for (int i=inf; i<=sup; i++)
         v[i] = vAux[i];
   }
   
   public static void mergeSort2 (int[] v) {
      ordenarPorMezcla2 (v, 0, v.length-1);
   }
   private static void ordenarPorMezcla2 (int[] v, int inf, int sup) {
      if (inf<sup) {
         int medio = (inf+sup)/2;
         ordenarPorMezcla2 (v, inf, medio);
         ordenarPorMezcla2 (v, medio+1, sup);
         mezclar2 (v, inf, medio, sup);
      }
   }
   private static void mezclar2 (int[] v, int inf, int medio, int sup) {
      int[] vAux = new int[sup-inf+1]; //vector auxiliar de longitud exacta
      int i1 = inf;
      int i2 = medio+1;
      int j = 0; //inicializaci�n de �ndice del vector auxiliar
      while (i1<=medio && i2<=sup) {
         if (v[i1]<v[i2]) {
            vAux[j] = v[i1];
            i1++;
         }
         else {
            vAux[j] = v[i2];
            i2++;
         }
         j++;
      }
      for (int i=i1; i<=medio; i++) {
         vAux[j] = v[i];
         j++;
      }
      for (int i=i2; i<=sup; i++) {
         vAux[j] = v[i];
         j++;
      }
      for (int i=inf; i<=sup; i++)
         v[i] = vAux[i-inf]; //transformaci�n de �ndices y copia
   }
   
   public static void mergeSort3 (int[] v) {
      int[] vAux = new int[v.length]; //vector auxiliar de longitud n, se propaga
      ordenarPorMezcla3 (v, 0, v.length-1, vAux);
   }
   private static void ordenarPorMezcla3 (int[] v, int inf, int sup, int[] vAux) {
      if (inf<sup) {
         int medio = (inf+sup)/2;
         ordenarPorMezcla3 (v, inf, medio, vAux);
         ordenarPorMezcla3 (v, medio+1, sup, vAux);
         mezclar3 (v, inf, medio, sup, vAux);
      }
   }
   private static void mezclar3 (int[] v, int inf, int medio, int sup, int [] vAux) {
      int i1 = inf;
      int i2 = medio+1;
      int j = inf;
      while (i1<=medio && i2<=sup) {
         if (v[i1]<v[i2]) {
            vAux[j] = v[i1];
            i1++;
         }
         else {
            vAux[j] = v[i2];
            i2++;
         }
         j++;
      }
      for (int i=i1; i<=medio; i++) {
         vAux[j] = v[i];
         j++;
      }
      for (int i=i2; i<=sup; i++) {
         vAux[j] = v[i];
         j++;
      }
      for (int i=inf; i<=sup; i++)
         v[i] = vAux[i];
   }
   
   // algoritmo de ordenaci�n r�pida
   public static void quickSort1 (int[] v) {
   // versi�n sencilla
      ordenarRapido1 (v, 0, v.length-1);
   }
   private static void ordenarRapido1 (int[] v, int inf, int sup) {
      if (inf<sup) {
         int med = partir (v, inf, sup);
         ordenarRapido1 (v, inf, med);
         ordenarRapido1 (v, med+1, sup);
      }
   }
   private static int partir (int[] v, int inf, int sup) {
      int piv  = v[inf];
      int izq  = inf+1;
      int dcha = sup;
      int temp;
      do {
         for (; v[izq]<=piv  && izq<sup   ; izq++);
         for (; v[dcha]>piv /*&&dcha>inf*/; dcha--);
         if (izq<dcha) {
            temp = v[izq];
            v[izq] = v[dcha];
            v[dcha] = temp;
         }
      } while (izq<dcha);
      /* v[inf] <-> v[dcha] */
      temp = v[inf];
      v[inf] = v[dcha];
      v[dcha] = temp;
      return dcha;
   }
   
   public static void quickSort2 (int[] v) {
   // versi�n mejorada en el no. de llamadas recursivas
      ordenarRapido2 (v, 0, v.length-1);
   }
   private static void ordenarRapido2 (int[] v, int inf, int sup) {
      if (inf<sup) {
         int med = partir (v, inf, sup);
         if (inf<med) ordenarRapido2 (v, inf, med-1);
         if (med<sup) ordenarRapido2 (v, med+1, sup);
      }
   }
}