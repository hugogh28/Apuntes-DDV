
/**
 * @author (�ngel Vel�zquez Iturbide, Departamento de Inform�tica y Estad�stica, Universidad Rey Juan Carlos)
 * Asignatura: Dise�o y An�lisis de Algoritmos, Grado en Ingenier�a Inform�tica
 * @version (Curso 2014-15)
*/
public class Puntos
{

   public static boolean[] PuntosMax1 (int[] px, int[] py) {
   // Algoritmo de divide y vencer�s, sencillo pero relativamente ineficiente O(n^2)
   // Suponemos que los puntos est�n ordenados por sus abcisas (xs),
   //    pero puede modificarse el algoritmo de forma que ordene un conjunto de puntos cualquiera
       boolean[] sol = new boolean[px.length];
       PM_DyV1 (px, py, 0, px.length-1, sol);
       return sol;
   }
   private static void PM_DyV1 (int[] px, int[] py, int inf, int sup, boolean[] sol) {
       if (inf==sup)
          sol[inf] = true;
       else {
          int medio = (inf+sup)/2;
          PM_DyV1 (px, py, inf,     medio, sol);
          PM_DyV1 (px, py, medio+1, sup,   sol);
          compararMaximales1 (px, py, inf, medio, sup, sol);
       }
   }
   private static void compararMaximales1 (int[] xs, int[] ys, int inf, int medio, int sup, boolean[] sol) {
   // Se comparan los pares de puntos de la mitad izq con la mitad dcha para determinar si son no maximales
      for (int i=inf; i<=medio; i++) {
         boolean maximal = true;
         for (int j=medio+1; (j<=sup) && maximal; j++)
            if (ys[i]<ys[j]) {
               maximal = false;
               sol[i] = false;
            }
      }
   }
   
   public static boolean[] PuntosMax2 (int[] px, int[] py) {
   // Algoritmo de divide y vencer�s, complicado pero eficiente O(n�logn)
   // Suponemos que los puntos est�n ordenados por sus abcisas (xs)
   // Se mantiene una lista ordenada por las ordenadas de los puntos, junto con enlaces a los puntos originales
       int[] qy  = new int[px.length];
       int[] qap = new int[px.length];
       for (int i=0; i<px.length; i++) {
          qy[i] = py[i];
          qap[i] = i;
       }
       ordenarYsEnlazar (qy, qap);
       boolean[] sol = new boolean[px.length];
       PM_DyV2 (px, py, qap, 0, px.length-1, sol);
       return sol;
   }
   private static void PM_DyV2 (int[] px, int[] py, int[] qap,
                                int inf, int sup, boolean[] sol) {
       if (inf==sup)
          sol[inf] = true;
       else {
          int medio = (inf+sup)/2;
          PM_DyV2 (px, py, qap, inf,     medio, sol);
          PM_DyV2 (px, py, qap, medio+1, sup,   sol);
          compararMaximales2 (qap, inf, medio, sup, sol);
       }
   }
   private static void compararMaximales2 (int[] qap, int inf, int medio, int sup, boolean[] sol) {
   // Se comparan los puntos en orden decreciente de y,
   //    descartando los maximales de la mitad izq que tengan un y menor que maximales de la mitad dcha
      boolean ya_no = false;
      for (int i=qap.length-1; i>=0; i--) {
         if ((qap[i]>=inf) && (qap[i]<=sup) && sol[qap[i]])
            if (qap[i]>medio)
               ya_no = true;
            else if (ya_no)
               sol[qap[i]] = false;
      }
   }
   
   private static void ordenarYsEnlazar (int[] qy, int[] qap) {
   // se ordenan por inserci�n
      for (int i=1; i<qy.length; i++) {
         int aux1 = qy[i];
         int aux2 = qap[i];
         int j;
         for (j=i-1; j>=0 && qy[j]>aux1; j--) {
            qy[j+1] = qy[j];
            qap[j+1] = qap[j];
         }
         qy[j+1] = aux1;
         qap[j+1] = aux2;
      }
   }

   public static boolean[] PuntosMax3 (int[] px, int[] py) {
   // Algoritmo de divide y vencer�s, complicado pero eficiente O(n�logn)
   // Los puntos est�n desordenados y se calcula un vector de �ndices, de c�mo �star�an dispuestos si se ordenaran por abcisas (xs)
   // Mantiene dos listas de puntos, una ordenada por sus abcisas y otra por sus ordenadas,
   //    junto con enlaces de la segunda lista a los puntos originales
       int[] qx  = new int[px.length];
       int[] qy  = new int[px.length];
       int[] qap = new int[px.length];
       for (int i=0; i<px.length; i++) {
          qx[i] = px[i];
          qy[i] = py[i];
          qap[i] = i;
       }
       int[] ind = ordenarXsIndices (px);
       ordenarYsEnlazar (qx, qy, qap);
       boolean[] sol = new boolean[px.length];
       PM_DyV3 (px, py, ind, qap, 0, px.length-1, sol);
       return sol;
   }
   private static void PM_DyV3 (int[] px, int[] py, int[] ind, int[] qap,
                                int inf, int sup, boolean[] sol) {
       if (inf==sup)
          sol[ind[inf]] = true;
       else {
          int medio = (inf+sup)/2;
          PM_DyV3 (px, py, ind, qap, inf,     medio, sol);
          PM_DyV3 (px, py, ind, qap, medio+1, sup,   sol);
          compararMaximales3 (qap, ind, inf, medio, sup, sol);
       }
   }
   private static void compararMaximales3 (int[] qap, int[] ind,
                                           int inf, int medio, int sup, boolean[] sol) {
      boolean ya_no = false;
      for (int i=qap.length-1; i>=0; i--) {
         if ((ind[qap[i]]>=inf) && (ind[qap[i]]<=sup) && sol[ind[qap[i]]])
            if (ind[qap[i]]>medio)
               ya_no = true;
            else if (ya_no)
               sol[ind[qap[i]]] = false;
      }
   }

   private static int[] ordenarXsIndices (int[] px) {
      int[] v2 = new int[px.length];
      v2[0] = 0;
      for (int i=1; i<px.length; i++) {
         int aux = px[i];
         int j;
         for (j=i-1; j>=0 && px[v2[j]]>aux; j--)
            v2[j+1] = v2[j];
         v2[j+1] = i;
      }
      return v2;
   }
    
   private static void ordenarYsEnlazar (int[] qx, int[] qy, int[] qap) {
      for (int i=1; i<qx.length; i++) {
         int aux1 = qx[i];
         int aux2 = qy[i];
         int aux3 = qap[i];
         int j;
         for (j=i-1; j>=0 && qy[j]>aux2; j--) {
            qx[j+1] = qx[j];
            qy[j+1] = qy[j];
            qap[j+1] = qap[j];
         }
         qx[j+1] = aux1;
         qy[j+1] = aux2;
         qap[j+1] = aux3;
      }
   }
       
}
