
/**
 * Write a description of class LineaDelCielo here.
 * 
 * @author (�ngel Vel�zquez Iturbide, Departamento de Inform�tica y Estad�stica, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos para Juegos, Grado en Dise�o y Desarrollo de Videojuegos
 * @version (Curso 2019-20)
 */
public class LineaDelCielo
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class LineaDelCielo
     */
    public LineaDelCielo()
    {
        // initialise instance variables
        x = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y 
     */
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
