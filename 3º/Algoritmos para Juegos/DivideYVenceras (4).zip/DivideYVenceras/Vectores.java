
/**
 * @author (�ngel Vel�zquez Iturbide, Departamento de Inform�tica y Estad�stica, Universidad Rey Juan Carlos)
 * Asignatura: Dise�o y An�lisis de Algoritmos, Grado en Ingenier�a Inform�tica
 * @version (Curso 2014-15)
 */
public class Vectores
{

   public static int subarraySumaMaxima (int[] v) {
      return sasmDyV (v, 0, v.length-1);
   }
   private static int sasmDyV (int[] v, int inf, int sup) {
      if (inf==sup)
         return v[inf];
      else {
         int med = (inf+sup)/2;
         int sm1 = sasmDyV (v, inf, med);
         int sm2 = sasmDyV (v, med+1, sup);
         int sm3 = maxSubarrayCruzado (v, inf, med, sup);
         return Math.max(Math.max(sm1, sm2),sm3);
      }
   }
   private static int maxSubarrayCruzado (int[] v, int inf, int med, int sup) {
      int maxSumIzq = 0;
      int sumIzq = 0;
      for (int i=med; i>=inf; i--) {
         sumIzq += v[i];
         if (sumIzq>maxSumIzq)
            maxSumIzq = sumIzq;
      }
      int maxSumDcha = 0;
      int sumDcha = 0;
      for (int i=med+1; i<=sup; i++) {
         sumDcha += v[i];
         if (sumDcha>maxSumDcha)
            maxSumDcha = sumDcha;
      }
      return maxSumIzq + maxSumDcha;
   }

   public static int sumaArray (int[] v) {
      return sumaDyV (v, 0, v.length-1);
   }
   private static int sumaDyV (int[] v, int inf, int sup) {
      if (inf==sup)
         return v[inf];
      else {
         int med = (inf+sup)/2;
         int suma1 = sumaDyV (v, inf, med);
         int suma2 = sumaDyV (v, med+1, sup);
         return suma1 + suma2;
      }
   }
 
   public static int seleccionar (int[] v, int k) {
      return select (v, 0, v.length-1, k);
   }
   private static int select (int[] v, int inf, int sup, int k) {
      int med = partir (v, inf, sup);
      if (med==inf+k)
         return v[med];
      else if (med<inf+k)
         return select (v, med+1, sup, k-(med-inf+1));
      else // med>inf+k
         return select (v, inf, med, k);
   }
   private static int partir (int[] v, int inf, int sup) {
      int piv  = v[inf];
      int izq  = inf+1;
      int dcha = sup;
      int temp;
      do {
         for (; v[izq]<=piv  && izq<sup   ; izq++);
         for (; v[dcha]>piv /*&&dcha>inf*/; dcha--);
         if (izq<dcha) {
            temp = v[izq];
            v[izq] = v[dcha];
            v[dcha] = temp;
         }
      } while (izq<dcha);
      /* v[inf] <-> v[dcha] */
      temp = v[inf];
      v[inf] = v[dcha];
      v[dcha] = temp;
      return dcha;
   }

}
