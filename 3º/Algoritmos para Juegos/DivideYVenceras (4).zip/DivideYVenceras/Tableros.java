
/**
 * Write a description of class Tableros here.
 * 
 * @author (�ngel Vel�zquez Iturbide, Departamento de Inform�tica y Estad�stica, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos para Juegos, Grado en Dise�o y Desarrollo de Videojuegos
 * @version (Curso 2019-20)
 */
public class Tableros
{
   public static int tableroDefectuoso1 (int dim, int f, int c) {
      int[][] tabl = new int[dim][dim];
      tabl[f][c] = 1;
      int num = tdDyV1 (tabl, f, c, 2, 0, tabl.length-1, 0, tabl.length-1);
      imprimirInt (tabl);
      return num;
   }
   private static int tdDyV1 (int[][] tabl, int f, int c, int num,
                              int fInicio, int fFin, int cInicio, int cFin) {
      if (fFin==fInicio+1) {
         if (!(fInicio==f && cInicio==c))
            tabl[fInicio][cInicio] = num;
         if (!(fInicio==f && cFin==c))
            tabl[fInicio][cFin]    = num;
         if (!(fFin==f && cInicio==c))
            tabl[fFin]   [cInicio] = num;
         if (!(fFin==f && cFin==c))
            tabl[fFin]   [cFin]    = num;
         return num+1;
      }
      else {
         // primero determina en qu� cuadrante est� la casilla defectuosa y despu�s realiza el tratamiento adecuado
         int fMedio = (fInicio+fFin)/2;
         int cMedio = (cInicio+cFin)/2;
         int cuadrante;
         if (f>=fInicio && f<=fMedio && c>=cInicio && c<=cMedio)
            cuadrante = 0;
         else if (f>=fInicio && f<=fMedio && c>cMedio && c<=cFin)
            cuadrante = 1;
         else if (f>fMedio && f<=fFin && c>=cInicio && c<=cMedio)
            cuadrante = 2;
         else
            cuadrante = 3;
         int num1, num2, num3, num4=0;
         switch (cuadrante) {
            case 0: { tabl[fMedio]  [cMedio+1] = num;
                      tabl[fMedio+1][cMedio]   = num;
                      tabl[fMedio+1][cMedio+1] = num;
                      num1 = tdDyV1 (tabl, f,        c,        num+1, fInicio, fMedio, cInicio,  cMedio);
                      num2 = tdDyV1 (tabl, fMedio,   cMedio+1, num1,  fInicio, fMedio, cMedio+1, cFin);
                      num3 = tdDyV1 (tabl, fMedio+1, cMedio,   num2,  fMedio+1, fFin,  cInicio,  cMedio);
                      num4 = tdDyV1 (tabl, fMedio+1, cMedio+1, num3,  fMedio+1, fFin,  cMedio+1, cFin);
                      break;
                    }
            case 1: { tabl[fMedio]  [cMedio]   = num;
                      tabl[fMedio+1][cMedio]   = num;
                      tabl[fMedio+1][cMedio+1] = num;
                      num1 = tdDyV1 (tabl, fMedio,   cMedio,   num+1, fInicio, fMedio, cInicio,  cMedio);
                      num2 = tdDyV1 (tabl, f,        c,        num1,  fInicio, fMedio, cMedio+1, cFin);
                      num3 = tdDyV1 (tabl, fMedio+1, cMedio,   num2,  fMedio+1, fFin,  cInicio,  cMedio);
                      num4 = tdDyV1 (tabl, fMedio+1, cMedio+1, num3,  fMedio+1, fFin,  cMedio+1, cFin);
                      break;
                    }
            case 2: { tabl[fMedio]  [cMedio]   = num;
                      tabl[fMedio]  [cMedio+1] = num;
                      tabl[fMedio+1][cMedio+1] = num;
                      num1 = tdDyV1 (tabl, fMedio,   cMedio,   num+1, fInicio, fMedio, cInicio,  cMedio);
                      num2 = tdDyV1 (tabl, fMedio,   cMedio+1, num1,  fInicio, fMedio, cMedio+1, cFin);
                      num3 = tdDyV1 (tabl, f,        c,        num2,  fMedio+1, fFin,  cInicio,  cMedio);
                      num4 = tdDyV1 (tabl, fMedio+1, cMedio+1, num3,  fMedio+1, fFin,  cMedio+1, cFin);
                      break;
                    }
            case 3: { tabl[fMedio]  [cMedio]   = num;
                      tabl[fMedio]  [cMedio+1] = num;
                      tabl[fMedio+1][cMedio]   = num;
                      num1 = tdDyV1 (tabl, fMedio,   cMedio,   num+1, fInicio, fMedio, cInicio,  cMedio);
                      num2 = tdDyV1 (tabl, fMedio,   cMedio+1, num1,  fInicio, fMedio, cMedio+1, cFin);
                      num3 = tdDyV1 (tabl, fMedio+1, cMedio,   num2,  fMedio+1, fFin,  cInicio,  cMedio);
                      num4 = tdDyV1 (tabl, f,        c,        num3,  fMedio+1, fFin,  cMedio+1, cFin);
                      break;
                    }
         }
         return num4;
      }
   }

   public static int tableroDefectuoso2 (int dim, int f, int c) {
      int[][] tabl = new int[dim][dim];
      tabl[f][c] = 0;
      int num = tdDyV2 (tabl, f, c, 1, 0, tabl.length-1, 0, tabl.length-1);
      imprimirInt (tabl);
      return num;
   }
   private static int tdDyV2 (int[][] tabl, int f, int c, int num,
                              int fInicio, int fFin, int cInicio, int cFin) {
      if (fFin==fInicio+1) {
         if (!(fInicio==f && cInicio==c))
            tabl[fInicio][cInicio] = num;
         if (!(fInicio==f && cFin==c))
            tabl[fInicio][cFin]    = num;
         if (!(fFin==f && cInicio==c))
            tabl[fFin]   [cInicio] = num;
         if (!(fFin==f && cFin==c))
            tabl[fFin]   [cFin]    = num;
         return num+1;
      }
      else {
         // va tratando cada cuadrante sucesivamente, determinando si contiene a la casilla defectuosa
         int fMedio = (fInicio+fFin)/2;
         int cMedio = (cInicio+cFin)/2;
         int num1, num2, num3, num4;
         // 1er cuadrante
         if (f>=fInicio && f<=fMedio && c>=cInicio && c<=cMedio)
            num1 = tdDyV2 (tabl, f, c, num+1, fInicio, fMedio, cInicio, cMedio);
         else {
            tabl[fMedio][cMedio] = num;
            num1 = tdDyV2 (tabl, fMedio, cMedio, num+1, fInicio, fMedio, cInicio, cMedio);
         }
         // 2o cuadrante
         if (f>=fInicio && f<=fMedio && c>cMedio && c<=cFin)
            num2 = tdDyV2 (tabl, f, c, num1, fInicio, fMedio, cMedio+1, cFin);
         else {
            tabl[fMedio][cMedio+1] = num;
            num2 = tdDyV2 (tabl, fMedio, cMedio+1, num1, fInicio, fMedio, cMedio+1, cFin);
         }
         // 3er cuadrante
         if (f>fMedio && f<=fFin && c>=cInicio && c<=cMedio)
            num3 = tdDyV2 (tabl, f, c, num2, fMedio+1, fFin, cInicio, cMedio);
         else {
            tabl[fMedio+1][cMedio] = num;
            num3 = tdDyV2 (tabl, fMedio+1, cMedio, num2, fMedio+1, fFin, cInicio, cMedio);
         }
         // 4o cuadrante
         if (f>fMedio && f<=fFin && c>cMedio && c<=cFin)
             num4 = tdDyV2 (tabl, f, c, num3, fMedio+1, fFin, cMedio+1, cFin);
         else {
             tabl[fMedio+1][cMedio+1] = num;
             num4 = tdDyV2 (tabl, fMedio+1, cMedio+1, num3, fMedio+1, fFin, cMedio+1, cFin);
         }
         return num4;
      }
   }

   public static char[][] fichas2n (int n) {
      // n es el n?umero de filas o columnas del tablero
      char[][] tabl = new char[n][n];
      fichasDyV (n, tabl, 0, n-1, 0, n-1);
      imprimirChar (tabl);
      return tabl;
   }
   private static void fichasDyV (int n, char[][] tabl, int fInicio, int fFin, int cInicio, int cFin) {
       if (n==2) {
          tabl[fInicio][cInicio] = 'X'; tabl[fInicio][cFin] = 'X';
          tabl[fFin   ][cInicio] = 'X'; tabl[fFin   ][cFin] = 'X';
       }
       else {
          int fMedio = (fInicio+fFin)/2;
          int cMedio = (cInicio+cFin)/2;
          fichasDyV (n/2, tabl, fInicio, fMedio, cInicio, cMedio);
          fichasDyV (n/2, tabl, fMedio+1, fFin, cMedio+1, cFin);
       }
   }

   private static void imprimirInt (int[][] tabl) {
      for (int i=0; i<=tabl.length-1; i++) {
         for (int j=0; j<=tabl.length-1; j++)
            System.out.print ((tabl[i][j]<=9?" "+tabl[i][j]:tabl[i][j])+"   ");
         System.out.println ();
      }
   }
   
   private static void imprimirChar (char[][] tabl) {
      for (int i=0; i<=tabl.length-1; i++) {
         for (int j=0; j<=tabl.length-1; j++)
            System.out.print ((tabl[i][j]=='X'?"X":"-")+" ");
         System.out.println ();
      }
   }
}
