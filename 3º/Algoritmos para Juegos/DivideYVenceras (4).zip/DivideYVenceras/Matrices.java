
/**
 * @author (�ngel Vel�zquez Iturbide, Departamento de Inform�tica y Estad�stica, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos para Juegos, Grado en Dise�o y Desarrollo de Videojuegos
 * @version (Curso 2019-20)
 */
public class Matrices
{

   public static void trasponer1 (int[][] m) {
      for (int i=0; i<m.length; i++)
         for (int j=0; j<m.length; j++) {
            int aux = m[i][j];
            m[i][j] = m[j][i];
            m[j][i] = aux;
         }
   }

   public static void trasponer2 (int[][] m) {
      for (int i=0; i<m.length; i++)
         for (int j=0; j<i; j++) {
            int aux = m[i][j];
            m[i][j] = m[j][i];
            m[j][i] = aux;
         }
   }
   
   public static void trasponer3 (int[][] m) {
      trasponerDyV1 (m, 0, m.length-1, 0, m.length-1);
   }
   private static void trasponerDyV1 (int[][] m, int fInicio, int fFin, int cInicio, int cFin) {
      // caso b�sico de 1x1
      if (fInicio<fFin) {
         int fMedio = (fInicio+fFin)/2;
         int cMedio = (cInicio+cFin)/2;
         trasponerDyV1 (m, fInicio, fMedio, cInicio, cMedio);
         trasponerDyV1 (m, fInicio, fMedio, cMedio+1, cFin);
         trasponerDyV1 (m, fMedio+1, fFin, cInicio, cMedio);
         trasponerDyV1 (m, fMedio+1, fFin, cMedio+1, cFin);
         intercambiar (m, fMedio+1, cInicio, fInicio, cMedio+1, fFin-fMedio);
      }
   }
   public static void intercambiar (int[][] m, int fIniA, int cIniA, int fIniB, int cIniB, int dimen) {
      for (int i=0; i<=dimen-1; i++)
         for (int j=0; j<=dimen-1; j++) {
            int aux = m[fIniA+i][cIniA+j];
            m[fIniA+i][cIniA+j] = m[fIniB+i][cIniB+j];
            m[fIniB+i][cIniB+j] = aux;
         }
   }

   public static void trasponer4 (int[][] m) {
      trasponerDyV2 (m, 0, m.length-1, 0, m.length-1);
   }
   private static void trasponerDyV2 (int[][] m, int fInicio, int fFin, int cInicio, int cFin) {
      // caso b�sico de 2x2
      if (fInicio==fFin-1) {
         int aux = m[fInicio][cFin];
         m[fInicio][cFin] = m[fFin][cInicio];
         m[fFin][cInicio] = aux;
      }
      else {
         int fMedio = (fInicio+fFin)/2;
         int cMedio = (cInicio+cFin)/2;
         trasponerDyV2 (m, fInicio, fMedio, cInicio, cMedio);
         trasponerDyV2 (m, fInicio, fMedio, cMedio+1, cFin);
         trasponerDyV2 (m, fMedio+1, fFin, cInicio, cMedio);
         trasponerDyV2 (m, fMedio+1, fFin, cMedio+1, cFin);
         intercambiar (m, fMedio+1, cInicio, fInicio, cMedio+1, fFin-fMedio);
      }
   }
     
}
