
/**
 * Write a description of class N_reinas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class N_reinas
{
   public static void nReinasVA_Todas (int n) {
      int[] c = new int[n];
      boolean[] f = new boolean[n];
      for (int i=0; i<n; i++)
         f[i] = true;
      boolean[] dp = new boolean[2*n-1];
      for (int i=0; i<2*n-1; i++)
         dp[i] = true;
      boolean[] ds = new boolean[2*n-1];
      for (int i=0; i<2*n-1; i++)
         ds[i] = true;
      buscarReinasT (n, 0, c, f, dp, ds);
   }
   private static void buscarReinasT (int n,
                                      int i,
                                      int[] solucion,
                                      boolean[] f,
                                      boolean[] dp,
                                      boolean[] ds) {
      if (i==n)
         imprimir(solucion);
      else
         for (int j=0; j<n; j++)
            if (f[j] && dp[i-j+n-1] && ds[i+j]) {
               solucion[i] = j;
               f[j] = false;
               dp[i-j+n-1] = false;
               ds[i+j] = false;
               buscarReinasT (n, i+1, solucion, f, dp, ds);
               f[j] = true;
               dp[i-j+n-1] = true;
               ds[i+j] = true;
            }
   }

   public static void nReinasVA (int n) {
      int[] c = new int[n];
      boolean[] f = new boolean[n];
      for (int i=0; i<n; i++)
         f[i] = true;
      boolean[] dp = new boolean[2*n-1];
      for (int i=0; i<2*n-1; i++)
         dp[i] = true;
      boolean[] ds = new boolean[2*n-1];
      for (int i=0; i<2*n-1; i++)
         ds[i] = true;
      boolean exito = buscarReinasVA (n, 0, c, f, dp, ds);
   }
   private static boolean buscarReinasVA (int n,
                                          int i,
                                          int[] solucion,
                                          boolean[] f,
                                          boolean[] dp,
                                          boolean[] ds) {
      boolean exito = false;
      if (i==n) {
         exito = true;
         imprimir(solucion);
      } else
         for (int j=0; j<n & !exito; j++)
            if (f[j] && dp[i-j+n-1] && ds[i+j]) {
               solucion[i] = j;
               f[j] = false;
               dp[i-j+n-1] = false;
               ds[i+j] = false;
               exito = buscarReinasVA (n, i+1, solucion, f, dp, ds);
               if (!exito) {
                  f[j] = true;
                  dp[i-j+n-1] = true;
                  ds[i+j] = true;
               }
            }
      return exito;
   }

   public static void nReinasEnum_Todas (int n) {
      int[] c = new int[n];
      boolean[] f = new boolean[n];
      for (int i=0; i<n; i++)
         f[i] = true;
      buscarReinasEnumT (n, 0, c, f);
   }
   private static void buscarReinasEnumT (int n,
                                          int i,
                                          int[] solucion,
                                          boolean[] libres) {
      if (i==n) {
         if (comprobarTablero(n,solucion))
            imprimir(solucion);
      } else 
         for (int j=0; j<n; j++) {
            if (libres[j]) {
               solucion[i] = j;
               libres[j] = false;
               buscarReinasEnumT (n, i+1, solucion, libres);
               libres[j] = true;
            }     
         }
   }
   
   private static boolean comprobarTablero (int n, int[] tablero) {
      boolean correcto = true;
      for (int i=0; (i<n) && correcto; i++)
         for (int j=i+1; (j<n) && correcto; j++)
            correcto = ((tablero[i]!=tablero[j])
                    && (i-tablero[i]!=j-tablero[j])
                    && (i+tablero[i]!=j+tablero[j]));
      return correcto;
   }

   public static void nReinasEnum (int n) {
      int[] c = new int[n];
      boolean[] f = new boolean[n];
      for (int i=0; i<n; i++)
         f[i] = true;
      boolean exito = buscarReinasEnum (n, 0, c, f);
   }
   private static boolean buscarReinasEnum (int n,
                                            int i,
                                            int[] solucion,
                                            boolean[] libres) {
      boolean exito = false;
      if (i==n) {
         exito = comprobarTablero(n,solucion);
         if (exito)
            imprimir(solucion);
      } else 
           for (int j=0; j<n & !exito; j++) {
              if (libres[j]) {
                 solucion[i] = j;
                 libres[j] = false;
                 exito = buscarReinasEnum (n, i+1, solucion, libres);
                 if (!exito)
                    libres[j] = true;
              }     
           }
      return exito;
   }
   
   private static void imprimir (int[] v) {
      for (int i=0; i<v.length; i++)
         System.out.print (v[i]+" ");
      System.out.println();
   }

}