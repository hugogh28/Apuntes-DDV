
/**
 * Write a description of class SumaDeSubconjuntos here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SumaDeSubconjuntos
{
   public static void sumaDeSubconjuntos (int[] ps, int s) {
      buscarSubconjs (0, ps, s, 0, new boolean[ps.length]);
   }
   private static void buscarSubconjs (int i,
                                       int[] ps,
                                       int s,
                                       int p,
                                       boolean[] subconj) {
      if (i==ps.length) {
         if (p==s)
            imprimir (subconj, ps);
      }
      else
         for (int k=0; k<=1; k++) {
            int nuevoP = p + k*ps[i];
            if (nuevoP<=s) {
               subconj[i] = (k==1);
               buscarSubconjs (i+1, ps, s, nuevoP, subconj);
            }
            // nuevoP = p - k*ps[i]; lo suprimimos por innecesario
          }
   }
   private static void imprimir (boolean[] v, int[] c) {
      for (int i=0; i<v.length; i++)
         System.out.print ((v[i]?c[i]:"-")+" ");
      System.out.println();
   }
}
