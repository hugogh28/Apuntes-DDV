
/**
 * Write a description of class QuinceMagico here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class QuinceMagico
{
   public static void quinceMagico1 () {
      boolean[] usado = {false,false,false,false,false,false,false,false,false};
      if (!buscarQuinceMagico (0, new int[9], usado))
         System.out.println ("No se encontr� soluci�n");
   }
   
   private static boolean buscarQuinceMagico (int i,
                                              int[] cuadrado,
                                              boolean[] usado) {
      boolean exito = false;
      if (i==9) {
          exito = true;
          imprimirCuadrado (cuadrado);
      }
      else
         for (int k=1; k<=9 && !exito; k++) {
            if (!usado[k-1]) {
               cuadrado[i] = k;
               if (esValido(cuadrado,i)) {
                  usado[k-1] = true;
                  exito = buscarQuinceMagico (i+1, cuadrado, usado);
                  if (!exito)
                     usado[k-1] = false;
               }
            }
         }
      return exito;
    }
    
   public static void quinceMagicoTodos () {
      boolean[] usado = {false,false,false,false,false,false,false,false,false};
      buscarQuinceMagicoT (0, new int[9], usado);
   }
   
   private static void buscarQuinceMagicoT (int i,
                                            int[] cuadrado,
                                            boolean[] usado) {
      if (i==9)
         imprimirCuadrado (cuadrado);
      else
         for (int k=1; k<=9; k++) {
            if (!usado[k-1]) {
               cuadrado[i] = k;
               if (esValido(cuadrado,i)) {
                  usado[k-1] = true;
                  buscarQuinceMagicoT (i+1, cuadrado, usado);
                  usado[k-1] = false;
               }
            }
         }
    }

    private static void imprimirCuadrado (int[] cuadrado) {
       System.out.println ("El cuadrado m�gico encontrado es:");
       for (int i=0; i<9; i++) {
          System.out.print (cuadrado[i] + " ");
          if ((i+1)%3==0)
             System.out.println();
        }
    }
    
    private static boolean esValido (int[] cuadrado, int i) {
       switch (i) {
          case 2 : return filaValida(cuadrado,0);
          case 5 : return filaValida(cuadrado,3);
          case 6 : return colValida(cuadrado,0) && diagSecundariaValida(cuadrado);
          case 7 : return colValida(cuadrado,1);
          case 8 : return filaValida(cuadrado,6) && colValida(cuadrado,2)
                       && diagPrincipalValida(cuadrado);
          default : return true;
       } 
    }
    
    private static boolean filaValida(int[] cuadrado, int i) {
       return (cuadrado[i]+cuadrado[i+1]+cuadrado[i+2]==15);
    }

    private static boolean colValida(int[] cuadrado, int i) {
       return (cuadrado[i]+cuadrado[i+3]+cuadrado[i+6]==15);
    }

    private static boolean diagPrincipalValida(int[] cuadrado) {
       return (cuadrado[0]+cuadrado[4]+cuadrado[8]==15);
    }

    private static boolean diagSecundariaValida(int[] cuadrado) {
       return (cuadrado[2]+cuadrado[4]+cuadrado[6]==15);
    }
}
