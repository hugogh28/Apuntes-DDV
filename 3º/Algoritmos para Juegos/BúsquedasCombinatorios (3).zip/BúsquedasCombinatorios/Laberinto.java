
/**
 * Write a description of class Laberinto here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Laberinto
{
   public static boolean hayCamino (char[][] laberinto) {
      int[] incrX = new int[] {1, 0, -1,  0};
      int[] incrY = new int[] {0, 1,  0, -1};
      laberinto[0][0] = 'C';
      boolean exito = buscar (0, 0, laberinto, incrX, incrY);
      if (exito)
         imprimir (laberinto);
      return exito;
   }
   private static boolean buscar (int x,
                                  int y,
                                  char[][] laberinto,
                                  int[] incrX,
                                  int[] incrY) {
      boolean exito = false;
      int n_1 = laberinto.length-1;
      if (x==n_1 && y==n_1)
         exito = true;
      else {
         for (int k=0; k<4 && !exito; k++) {
            int coordX = x + incrX[k];
            int coordY = y + incrY[k];
            if (coordX>=0 && coordX<=n_1 &&
                coordY>=0 && coordY<=n_1)
                if (laberinto[coordY][coordX] == ' ') {
                   laberinto[coordY][coordX] = 'C';
                   exito = buscar (coordX, coordY, laberinto, incrX, incrY);
                   if (!exito)
                      laberinto[coordY][coordX] = ' ';
                }
         }
      }
      return exito;
   }
   
    private static void imprimir (char[][] laberinto) {
      for (int i=0; i<laberinto.length; i++) {
         for (int j=0; j<laberinto.length; j++)
            System.out.print (laberinto[i][j]+" ");
         System.out.println();
      }
   }
}
