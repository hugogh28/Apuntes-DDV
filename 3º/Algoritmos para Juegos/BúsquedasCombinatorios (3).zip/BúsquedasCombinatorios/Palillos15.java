
/**
 * Contiene un m�todo para el problema de los 15 palillos, que es f�cil modificar para hacer otras indagaciones relacionados con este juego.
 * Est� basado en el art�culo de Jerome L. Lewis, "The 15-pegs puzzle and the conceptual tree", SIGCSE Bulletin, 20(4):15-18 y 28, dic. 1988.
 * 
 * @author (J. �ngel Vel�zquez Iturbide, Departamento de Inform�tica y Estad�stica, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos Avanzados, Grados en Ingenier�a Inform�tica e Ingenier�a de Computadores
 * @version (Curso 2023-24)
 */
public class Palillos15
{

   public static int Palillos15_a (int celda) {
   // el m�todo devuelve el n�mero de la celda donde queda finalmente el palillo 
      boolean[] triangulo = new boolean[15];
      for (int i=0; i<triangulo.length; i++)
         triangulo[i] = true;  // palillos
      triangulo[celda]= false; // hueco
      System.out.println("Hueco inicial: " + celda);
      // int[][] movs = new int[3][36];
      int[][] movs = {{0, 0, 1, 1, 2, 2, 3, 3, 3, 3, 4, 4, 5, 5, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9,10,10,11,11,12,12,12,12,13,13,14,14},
                      {1, 2, 3, 4, 4, 5, 1, 4, 6, 7, 7, 8, 2, 4, 8, 9, 3, 7, 4, 8, 4, 7, 5, 8, 6,11, 7,12, 7, 8,11,13, 8,12, 9,13},
                      {3, 5, 6, 8, 7, 9, 0, 5,10,12,11,13, 0, 3,12,14, 1, 8, 2, 9, 1, 6, 2, 7, 3,12, 4,13, 3, 5,10,14, 4,11, 5,12}};
      int celda2 = buscar15Palillos_a (2, triangulo, movs);
      System.out.println("Hueco final: " + celda2);
      return celda2;
   }

   private static int buscar15Palillos_a (int i, boolean[] triangulo, int[][] movs) {
      boolean exito = false;
      int sol = -1;
      if (i==15) {
          exito = true;
          sol = restante(triangulo);
      }
      else {
         for (int j=0; j<36 && !exito; j++)
            if (triangulo[movs[0][j]] && triangulo[movs[1][j]] && !triangulo[movs[2][j]]) {
               triangulo[movs[0][j]] = false;
               triangulo[movs[1][j]] = false;
               triangulo[movs[2][j]] = true;
               sol = buscar15Palillos_a (i+1, triangulo, movs);
               exito = (sol!=-1);
               if (exito)
                  // la secuencia de movimientos se imprime en orden inverso 
                  System.out.println ("Movimiento del agujero " + movs[0][j] + " al " + movs[2][j]);                   
               else {
                  triangulo[movs[0][j]] = true;
                  triangulo[movs[1][j]] = true;
                  triangulo[movs[2][j]] = false;
               }  
            }
      }
      return sol;
   }
      
   public static int Palillos15_b (int celda) {
   // el m�todo devuelve el n�mero de la celda donde queda finalmente el palillo 
   // versi�n que recuerda movimientos pasados y los evita
      boolean[] triangulo = new boolean[15];
      for (int i=0; i<triangulo.length; i++)
         triangulo[i] = true;  // palillos
      triangulo[celda]= false; // hueco
      System.out.println("Hueco inicial: " + celda);
      // int[][] movs = new int[3][36];
      int[][] movs = {{0, 0, 1, 1, 2, 2, 3, 3, 3, 3, 4, 4, 5, 5, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9,10,10,11,11,12,12,12,12,13,13,14,14},
                      {1, 2, 3, 4, 4, 5, 1, 4, 6, 7, 7, 8, 2, 4, 8, 9, 3, 7, 4, 8, 4, 7, 5, 8, 6,11, 7,12, 7, 8,11,13, 8,12, 9,13},
                      {3, 5, 6, 8, 7, 9, 0, 5,10,12,11,13, 0, 3,12,14, 1, 8, 2, 9, 1, 6, 2, 7, 3,12, 4,13, 3, 5,10,14, 4,11, 5,12}};
      boolean[] jugados = new boolean[32768];
      for (int i=0; i<jugados.length; i++)
         jugados[i] = false;
      jugados[convertir(triangulo)] = true;
      int celda2 = buscar15Palillos_b (2, triangulo, movs, jugados);
      System.out.println("Hueco final: " + celda2);
      return celda2;
   }

   private static int buscar15Palillos_b (int i, boolean[] triangulo, int[][] movs, boolean[] jugados) {
      boolean exito = false;
      int sol = -1;
      if (i==15) {
          exito = true;
          sol = restante(triangulo);
      }
      else {
         for (int j=0; j<36 && !exito; j++)
            if (triangulo[movs[0][j]] && triangulo[movs[1][j]] && !triangulo[movs[2][j]]) {
               triangulo[movs[0][j]] = false;
               triangulo[movs[1][j]] = false;
               triangulo[movs[2][j]] = true;
               int nuevo = convertir(triangulo);
               if (!jugados[nuevo]) {
                  jugados[nuevo] = true;
                  sol = buscar15Palillos_b (i+1, triangulo, movs, jugados);
                  exito = (sol!=-1);
               }
               if (exito)
                  // la secuencia de movimientos se imprime en orden inverso 
                  System.out.println ("Movimiento del agujero " + movs[0][j] + " al " + movs[2][j]);                   
               else {
                  triangulo[movs[0][j]] = true;
                  triangulo[movs[1][j]] = true;
                  triangulo[movs[2][j]] = false;
               }  
            }
      }
      return sol;
   }
      
   private static int convertir (boolean[] v) {
      int suma = 0;
      for (int i=0; i<v.length; i++)
         suma = 2*suma + (v[i]?1:0);
      return suma;
   }
      
   private static int restante (boolean[] triangulo) {
      int i=0;
      while (!triangulo[i])
         i++;
      return i;
   }

}
