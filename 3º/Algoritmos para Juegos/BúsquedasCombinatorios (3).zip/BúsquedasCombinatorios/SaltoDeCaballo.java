
/**
 * Write a description of class SaltoDeCaballo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SaltoDeCaballo
{
   public static boolean saltoCaballo (int f, int c, int lado) {
      int[][] tablero = new int[lado][lado];
      int[] incrX = new int[] {-1,  1,  2, 2, 1, -1, -2, -2};
      int[] incrY = new int[] {-2, -2, -1, 1, 2,  2,  1, -1};
      tablero[f][c] = 1;
      boolean hay = buscar (1, f, c, tablero, incrX, incrY);
      if (hay)
         imprimir (tablero);
      return hay;
   }
   private static boolean buscar (int i,
                                  int f,
                                  int c,
                                  int[][] recorrido,
                                  int[] incrX,
                                  int[] incrY) {
      boolean exito = false;
      if (i==recorrido.length*recorrido.length)
          exito = true;
      else
         for (int k=0; k<8 && !exito; k++) {
            int nuevaF = f + incrY[k];
            int nuevaC = c + incrX[k];
            if (nuevaF>=0 && nuevaF<recorrido.length &&
                nuevaC>=0 && nuevaC<recorrido.length)
               if (recorrido[nuevaF][nuevaC] == 0) {
                  recorrido[nuevaF][nuevaC] = i+1;
                  exito = buscar (i+1, nuevaF, nuevaC, recorrido, incrX, incrY);
                  if (!exito)
                     recorrido[nuevaF][nuevaC] = 0;
               }
         }
      return exito;
   }
   private static void imprimir (int[][] tablero) {
      for (int i=0; i<tablero.length; i++) {
         for (int j=0; j<tablero.length; j++)
            System.out.print (((tablero[i][j]<10)?" ":"")+tablero[i][j]+"  ");
         System.out.println();
      }
   }

}
