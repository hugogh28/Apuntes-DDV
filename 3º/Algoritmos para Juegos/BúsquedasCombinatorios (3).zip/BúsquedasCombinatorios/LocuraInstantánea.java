
/**
 * @author (�ngel Vel�zquez Iturbide, Departamento de Inform�tica y Estad�stica, Universidad Rey Juan Carlos)
 * Asignatura: Algoritmos Avanzados, Grado en Ingenier�a Inform�tica
 * @version (Curso 2016-17)
 */
public class LocuraInstant�nea
{

   public static void locuraInstant�nea () {
      char[][] cubos = {{'A','V','B','V','A','R'},
                        {'B','V','A','B','R','R'},
                        {'V','B','R','A','R','R'},
                        {'A','R','V','V','B','B'}};
      int[][] movs = new int[24][6];
      movs = calcularMovs();
      char[][] solucion = new char[4][6];
      buscarCubos (0, solucion, cubos, movs);
   }
   
   private static void buscarCubos (int i,
                                    char[][] solucion,
                                    char[][] cubos,
                                    int[][] movs) {
      if (i==4)
         imprimir(solucion);
      else
         for (int j=0; j<24; j++) {
            solucion[i] = calcularCubo(cubos[i], movs[j]);
            if (v�lida(solucion,i))
               buscarCubos (i+1, solucion, cubos, movs);
      }
   }

   private static char[] calcularCubo (char[] cubo, int[] mov) {
      char[] cubo2 = new char[cubo.length];
      for (int i=0; i<6; i++)
         cubo2[i] = cubo[mov[i]];
      return cubo2;
   }
   
   private static boolean v�lida (char[][] sol, int i) {
      boolean bien = true;
      for (int k=0; k<i && bien; k++)
         for (int j=1; j<5 && bien; j++)
            bien = (sol[i][j] != sol[k][j]);
      return bien;
   }
   
   private static void imprimir (char[][] solucion) {
      for (int i=0; i<4; i++){
         for (int j=0; j<6; j++)
            System.out.print (solucion[i][j]+" ");
         System.out.println();
      }
      System.out.println();
   }

   private static int[][] calcularMovs () {
      int[][] movs = new int[24][6];
      // disposici�n original y sus tres rotaciones
      movs[ 0] = new int[] {0,1,2,3,4,5};
      movs[ 1] = rotate(movs[0]);
      movs[ 2] = rotate(movs[1]);
      movs[ 3] = rotate(movs[2]);
      // una rotaci�n de las cuatro disposiciones anteriores
      movs[ 4] = twist(movs[0]);
      movs[ 5] = twist(movs[1]);
      movs[ 6] = twist(movs[2]);
      movs[ 7] = twist(movs[3]);
      // y otra rotaci�n m�s
      movs[ 8] = twist(movs[4]);
      movs[ 9] = twist(movs[5]);
      movs[10] = twist(movs[6]);
      movs[11] = twist(movs[7]);
      // un giro de las doce disposiciones anteriores
      movs[12] = flip(movs[0]);
      movs[13] = flip(movs[1]);
      movs[14] = flip(movs[2]);
      movs[15] = flip(movs[3]);
      movs[16] = flip(movs[4]);
      movs[17] = flip(movs[5]);
      movs[18] = flip(movs[6]);
      movs[19] = flip(movs[7]);
      movs[20] = flip(movs[8]);
      movs[21] = flip(movs[9]);
      movs[22] = flip(movs[10]);
      movs[23] = flip(movs[11]);
      return movs;
   }
   
   private static int[] rotate (int[] cubo) {
      int[] cubo2 = new int[6];
      cubo2[0] = cubo[0];
      cubo2[1] = cubo[2];
      cubo2[2] = cubo[3];
      cubo2[3] = cubo[4];
      cubo2[4] = cubo[1];
      cubo2[5] = cubo[5];
      return cubo2;
   }

   private static int[] twist (int[] cubo) {
      int[] cubo2 = new int[6];
      cubo2[0] = cubo[1];
      cubo2[1] = cubo[2];
      cubo2[2] = cubo[0];
      cubo2[3] = cubo[4];
      cubo2[4] = cubo[5];
      cubo2[5] = cubo[3];
      return cubo2;
   }

   private static int[] flip (int[] cubo) {
      int[] cubo2 = new int[6];
      cubo2[0] = cubo[5];
      cubo2[1] = cubo[4];
      cubo2[2] = cubo[3];
      cubo2[3] = cubo[2];
      cubo2[4] = cubo[1];
      cubo2[5] = cubo[0];
      return cubo2;
   }

}
