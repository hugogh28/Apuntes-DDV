/// @ref gtc_ulp
///

