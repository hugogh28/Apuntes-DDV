#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>

__global__ void scalaradd(const int* a, const int* b, int* c) {

	*c = *a + *b;
}

int main(int argc, char** argv) {

	int a, b, c;
	a = 2;
	b = 7;

	//declare GPU memory pointers
	int* d_a;
	int* d_b;
	int* d_c;

	//Allocate GPU memory
	const size_t INT_BYTES = sizeof(int);
	cudaMalloc(&d_a, INT_BYTES);
	cudaMalloc(&d_b, INT_BYTES);
	cudaMalloc(&d_c, INT_BYTES);

	//Transfer the scalars to the GPU memory
	cudaMemcpy(d_a, &a, INT_BYTES, cudaMemcpyHostToDevice);
	cudaMemcpy(d_b, &b, INT_BYTES, cudaMemcpyHostToDevice);

	//launch the kernel
	scalaradd <<<1, 1 >>> (d_a, d_b, d_c);
	//copy back the result to the GPU
	cudaMemcpy(&c, d_c, INT_BYTES, cudaMemcpyDeviceToHost);

	//print out the result
	printf("c = %d + %d = %d\n", a, b, c);

	//free GPU memory allocation
	cudaFree(d_a);
	cudaFree(d_b);
	cudaFree(d_c);

	d_a = d_b = d_c = NULL;
}

