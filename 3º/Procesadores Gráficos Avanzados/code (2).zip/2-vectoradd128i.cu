#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>

int main(int argc, char** argv) {

	const size_t ARRAY_SIZE = 128;
	const size_t ARRAY_BYTES = ARRAY_SIZE * sizeof(float);

	//generate the input arrays on the host
	float h_arr1[ARRAY_SIZE];
	float h_arr2[ARRAY_SIZE];

	for (size_t i = 0; i < ARRAY_SIZE; i++) {
		h_arr1[i] = rand() % 10;
		h_arr2[i] = rand() % 10;
	}

	//declare GPU memory pointers
	float* d_arr1;
	float* d_arr2;
	float* d_out;

	//Allocate GPU memory
	cudaMalloc(&d_arr1, ARRAY_BYTES);
	cudaMalloc(&d_arr2, ARRAY_BYTES);
	cudaMalloc(&d_out, ARRAY_BYTES);

	//Transfer the arrays to the GPU memory
	cudaMemcpy(d_arr1, h_arr1, ARRAY_BYTES, cudaMemcpyHostToDevice);
	cudaMemcpy(d_arr2, h_arr2, ARRAY_BYTES, cudaMemcpyHostToDevice);

	//launch the kernel

	//copy back the result array to the GPU
	float h_out[ARRAY_SIZE];
	cudaMemcpy(h_out, d_out, ARRAY_BYTES, cudaMemcpyDeviceToHost);

	//print out the resulting array
	for (size_t i = 0; i < ARRAY_SIZE; i++)
		printf("out[%d] = %.1f + %.1f = %.1f\n", i, h_arr1[i], h_arr2[i], h_out[i]);

	//free GPU memory allocation
	cudaFree(d_arr1);
	cudaFree(d_arr2);
	cudaFree(d_out);

	d_arr1 = d_arr2 = d_out = NULL;

}

