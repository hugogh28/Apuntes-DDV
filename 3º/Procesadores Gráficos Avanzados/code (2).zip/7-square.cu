#include <cuda_runtime.h>
#include <cstdio>
#include <cmath>
#include <cstdlib>

__global__ void square (float* out, float* in, const size_t N){

	size_t idx = blockIdx.x * blockDim.x  + threadIdx.x;

	if (idx < N) {
		float f = in[idx];
		out[idx] = f * f;
	}
		
}


int main (int argc, char** argv){

	const size_t ARRAY_SIZE = 10000; // use dynamic memory allocation for large array sizes
	const size_t ARRAY_BYTES = ARRAY_SIZE * sizeof(float);
		
	//generate the input array on the host
	float h_in [ARRAY_SIZE];
	for (size_t i=0; i<ARRAY_SIZE; i++){
		h_in[i] = rand() % 10;
	}

	//declare GPU memory pointers
	float *d_in;
	float *d_out;

	//Allocate GPU memory
	cudaMalloc(&d_in, ARRAY_BYTES);
	cudaMalloc(&d_out, ARRAY_BYTES);

	//Transfer the array to the GPU memory
	cudaMemcpy(d_in, h_in, ARRAY_BYTES, cudaMemcpyHostToDevice);

	//launch the kernel
	const size_t THREADS_PER_BLOCK = 256; // 128, 256, 512, 1024
	const size_t BLOCKS_PER_GRID = ceil ((float) ARRAY_SIZE/THREADS_PER_BLOCK);
	square<<<BLOCKS_PER_GRID, THREADS_PER_BLOCK >>> (d_out, d_in, ARRAY_SIZE);

	//copy back the result array to the GPU
	float h_out[ARRAY_SIZE];
	cudaMemcpy(h_out, d_out, ARRAY_BYTES, cudaMemcpyDeviceToHost);

	//print out the resulting array
	for (size_t i=0; i<ARRAY_SIZE; i++)
		printf("[%d]  %.1f-> %.1f\n", i, h_in[i], h_out[i]);
	
	//free GPU memory allocation
	cudaFree(d_in);
	cudaFree(d_out);
	d_in = d_out = NULL;
}


