#include <cstdio>

__global__ void helloBlock() {
	printf("Hello world! I'm a thread in block %d\n", blockIdx.x);
}

int main(int argc, char** argv) {

	const unsigned int BLOCKS_PER_GRID = 16;
	const unsigned int THREADS_PER_BLOCK = 1;

	helloBlock << <BLOCKS_PER_GRID, THREADS_PER_BLOCK >> > ();
	cudaDeviceSynchronize();
	return EXIT_SUCCESS;
}

