#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include "GPUTimer.h"

__host__ __device__ void clamp(int& pos, int maxpos) {
	pos = pos > 0 ? pos : 0;
	pos = pos < (maxpos - 1) ? pos : (maxpos - 1);
}

__global__
void conv2DGPUShared(float* const out, 
	float* const in,
	int width, int height,
	float* kernel, const int kernelSize)
{
	extern __shared__ float sharedMemory[];

	size_t x = blockIdx.x * blockDim.x + threadIdx.x;
	size_t y = blockIdx.y * blockDim.y + threadIdx.y;
	
	int idx = y * width + x;
	int halfKernelSize = kernelSize / 2;
	
	int posToLoadFromX = x - halfKernelSize;
	int posToLoadFromY = y - halfKernelSize;

	clamp(posToLoadFromX, width);
	clamp(posToLoadFromY, height);

	int posToLoadFromXOriginal = posToLoadFromX;
	int posToLoadFromYOriginal = posToLoadFromY;

	//case 0: load a global matrix roi. pos: (x-halfKernelSize, y-halKernelSize), size: (blockDimX, blockDimY)
	sharedMemory[threadIdx.y * (blockDim.x + kernelSize - 1) + threadIdx.x] = in[posToLoadFromY * width + posToLoadFromX];
	
	// case1: apron pixels - load bottom rows
	if (threadIdx.y >= (blockDim.y - kernelSize + 1)) {
		posToLoadFromY = y + halfKernelSize;
		clamp(posToLoadFromY, height);
		sharedMemory[(threadIdx.y + kernelSize - 1) * (blockDim.x + kernelSize - 1) + threadIdx.x] = in[posToLoadFromY * width + posToLoadFromXOriginal];
	}

	// case2: apron pixels - load right columns
	if (threadIdx.x >= (blockDim.x - kernelSize + 1)) {
		posToLoadFromX = x + halfKernelSize;
		clamp(posToLoadFromX, width);
		sharedMemory[(threadIdx.y) * (blockDim.x + kernelSize - 1) + threadIdx.x + kernelSize - 1] = in[posToLoadFromYOriginal * width + posToLoadFromX];
	}

	// cas3: apron pixels - load the remaining apron area (remaining kernelSizexKernelSize bottom-right region)
	if (threadIdx.x < (kernelSize - 1) && threadIdx.y < (kernelSize - 1)) {
		posToLoadFromX = x - halfKernelSize + blockDim.x;
		posToLoadFromY = y - halfKernelSize + blockDim.y;
		clamp(posToLoadFromX, width);
		clamp(posToLoadFromY, height);
		sharedMemory[(threadIdx.y + blockDim.y) * (blockDim.x + kernelSize - 1) + threadIdx.x + blockDim.x] = in[posToLoadFromY * width + posToLoadFromX];
	}

	__syncthreads();

	if (x >= width || y >= height) return;

	float convResult = 0.0f;
	for (int krow = 0; krow < kernelSize; krow++) {
		for (int kcol = 0; kcol < kernelSize; kcol++) {
			int neighborRow = threadIdx.y + krow;
			int neighborCol = threadIdx.x + kcol;
			float value = sharedMemory[neighborRow * (blockDim.x + kernelSize - 1) + neighborCol];
			convResult += kernel[krow * kernelSize + kcol] * value;
		}
	}
	out[idx] = convResult;

}

__global__
void conv2DGPU(float* out, float* const in, int width, int height,
	float* kernel, const int kernelSize)
{
	size_t x = blockIdx.x * blockDim.x + threadIdx.x;
	size_t y = blockIdx.y * blockDim.y + threadIdx.y;

	if (x >= width || y >= height) return;

	int idx = y * width + x;

	int halfKernelSize = kernelSize / 2;
	float convResult = 0.0f;
	for (int krow = 0; krow < kernelSize; krow++) {
		for (int kcol = 0; kcol < kernelSize; kcol++) {
			int neighborRow = y + (krow - halfKernelSize);
			clamp(neighborRow, height);

			int neighborCol = x + (kcol - halfKernelSize);
			clamp(neighborCol, width);

			convResult += kernel[krow * kernelSize + kcol] * in[neighborRow * width + neighborCol];
		}
	}

	out[idx] = convResult;

}

void conv2DCPU(float* out, float* in, int width, int height, float* kernel, int kernelSize) {

	int halfKernelSize = kernelSize / 2;

	for (int row = 0; row < height; row++) {
		for (int col = 0; col < width; col++) {
			float convResult = 0.0f;
			// Apply kernel to each input coordinate (row, col)
			for (int krow = 0; krow < kernelSize; krow++) {
				for (int kcol = 0; kcol < kernelSize; kcol++) {
					int neighborRow = row + (krow - halfKernelSize);
					clamp(neighborRow, height);

					int neighborCol = col + (kcol - halfKernelSize);
					clamp(neighborCol, width);

					convResult += kernel[krow * kernelSize + kcol] * in[neighborRow * width + neighborCol];
				}
			}
			// Write the convolution result at the same coordinate (row, col)
			out[col + width * row] = convResult;
		}
	}
}

bool checkResults(float* r1, float* r2, int numElements) {
	double EPSILON = 1e-04;

	for (int i = 0; i < numElements; i++) {
		if (fabs(r1[i] - r2[i]) > EPSILON)
			return false;
	}

	return true;
}


int main(int argc, char** argv) {

	const float TRIALS = 10.0f;

	const size_t WIDTH = 256;
	const size_t HEIGHT = 256;
	const size_t NUM_ELEMENTS = WIDTH * HEIGHT;
	const size_t ARRAY_BYTES = NUM_ELEMENTS * sizeof(float);

	const size_t KERNEL_SIZE = 3;
	const size_t KERNEL_ELEMENTS = KERNEL_SIZE * KERNEL_SIZE;
	const size_t KERNEL_BYTES = KERNEL_ELEMENTS * sizeof(float);

	const size_t MAX_VALUE = 255;

	//generate the input array on the host
	float* h_in = (float*)malloc(ARRAY_BYTES);
	for (size_t i = 0; i < NUM_ELEMENTS; i++) {
		h_in[i] = float(rand() % MAX_VALUE);
	}

	//generate the input kernel on the host
	float* h_kernel = (float*)malloc(KERNEL_BYTES);
	for (size_t i = 0; i < KERNEL_ELEMENTS; i++) {
		h_kernel[i] = float(1. / KERNEL_ELEMENTS);
	}

	//declare GPU memory pointers
	float* d_in;
	float* d_out;
	float* d_kernel;

	//Allocate GPU memory
	cudaMalloc(&d_in, ARRAY_BYTES);
	cudaMalloc(&d_out, ARRAY_BYTES);
	cudaMalloc(&d_kernel, KERNEL_BYTES);

	//Transfer the array to the GPU memory
	cudaMemcpy(d_in, h_in, ARRAY_BYTES, cudaMemcpyHostToDevice);
	cudaMemcpy(d_kernel, h_kernel, KERNEL_BYTES, cudaMemcpyHostToDevice);

	//run conv2D on GPU (global memory)
	const dim3 blockSize(16, 16, 1);
	const dim3 gridSize(ceil((float)WIDTH / blockSize.x), ceil((float)HEIGHT / blockSize.y), 1);
	GpuTimer timer;
	timer.Start();
	for (int i = 0; i < TRIALS; i++)
	{
		conv2DGPU << <gridSize, blockSize >> > (d_out, d_in, WIDTH, HEIGHT, d_kernel, KERNEL_SIZE);
	}
	timer.Stop();
	printf("GPU (Global) - average time elapsed: %f\n", timer.Elapsed() / (TRIALS * 1000));

	//run conv2D on GPU (shared memory)
	int sharedSize = (blockSize.x + KERNEL_SIZE - 1) * (blockSize.y + KERNEL_SIZE - 1) * sizeof(float);
	timer.Start();
	for (int i = 0; i < TRIALS; i++)
	{
		conv2DGPUShared << <gridSize, blockSize, sharedSize >> > (d_out, d_in, WIDTH, HEIGHT, d_kernel, KERNEL_SIZE);
	}
	timer.Stop();
	printf("GPU (shared) - average time elapsed: %f\n", timer.Elapsed() / (TRIALS * 1000));

	//copy back the result array to the GPU
	float* h_out = (float*)malloc(ARRAY_BYTES);
	cudaMemcpy(h_out, d_out, ARRAY_BYTES, cudaMemcpyDeviceToHost);

	//run conv2D on CPU
	float* h_expectedResult = (float*)malloc(ARRAY_BYTES);
	clock_t t = clock();
	for (int i = 0; i < TRIALS; i++)
	{
		conv2DCPU(h_expectedResult, h_in, WIDTH, HEIGHT, h_kernel, KERNEL_SIZE);
	}
	t = clock() - t;
	printf("CPU - average time elapsed: %f\n", ((float)t) / (TRIALS * CLOCKS_PER_SEC));

	//compare CPU and GPU results.
	bool success = checkResults(h_out, h_expectedResult, NUM_ELEMENTS);
	if (success)
		printf("Conv2D was succesfully computed on GPU and CPU\n");
	else
		printf("Conv2D. Something was wrong. CPU and GPU results show differences\n");

	//free GPU memory allocation
	cudaFree(d_in);
	cudaFree(d_out);
	cudaFree(d_kernel);

	free(h_in);
	free(h_kernel);
	free(h_out);
	free(h_expectedResult);
}

