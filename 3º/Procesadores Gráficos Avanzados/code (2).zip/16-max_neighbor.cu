#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>

__global__ void maxNeighbor(float* out, float* in, const size_t N, const size_t neighbors) {


	// sdata is allocated in the kernel call: 3rd arg to <<<b, t, shmem>>>
	extern __shared__ float sharedMemory[];

	size_t idx = blockIdx.x * blockDim.x + threadIdx.x;

	if (idx >= N)
		return;

	int sharedIdx = threadIdx.x;

	// load shared mem from global mem
	sharedMemory[sharedIdx] = in[idx];
	
	if (threadIdx.x < neighbors) {
		sharedMemory[sharedIdx+blockDim.x] = in[idx + blockDim.x];
	}	
	__syncthreads();  // make sure entire block is loaded!

	float maxSoFar = sharedMemory[sharedIdx];
	for (size_t i = 1; i < neighbors; i++) {

		maxSoFar = fmaxf(maxSoFar, sharedMemory[sharedIdx+i]);
	}

	out[idx] = maxSoFar;
	
}


int main() {

	const unsigned long long ARRAY_SIZE = 1000;
	const unsigned long long ARRAY_BYTES = ARRAY_SIZE * sizeof(float);
	const size_t NEIGHBORS = 3;

	//generate the input arrays on the host
	float* h_in = (float*)malloc(ARRAY_BYTES);

	for (int i = 0; i < ARRAY_SIZE; i++) {
		h_in[i] = rand() % 10;
	}

	//declare GPU memory pointers
	float* d_in;
	float* d_out;

	//Allocate GPU memory
	cudaMalloc(&d_in, ARRAY_BYTES);
	cudaMalloc(&d_out, ARRAY_BYTES);

	//Transfer the arrays to the GPU memory
	cudaMemcpy(d_in, h_in, ARRAY_BYTES, cudaMemcpyHostToDevice);

	//launch the kernel
	const size_t THREADS_PER_BLOCK = 256; // 128, 256, 512, 1024
	const size_t BLOCKS_PER_GRID = ceil((float)ARRAY_SIZE / THREADS_PER_BLOCK);
	const size_t SHARED_MEM = (THREADS_PER_BLOCK + NEIGHBORS) * sizeof(float);
	maxNeighbor << <BLOCKS_PER_GRID, THREADS_PER_BLOCK, SHARED_MEM >> > (d_out, d_in, ARRAY_SIZE, NEIGHBORS);
	
	//copy back the result array to the GPU
	float* h_out = (float*)malloc(ARRAY_BYTES);
	cudaMemcpy(h_out, d_out, ARRAY_BYTES, cudaMemcpyDeviceToHost);

	//print out the resulting array
	for (unsigned long long i = 0; i < ARRAY_SIZE; i++)
		printf("[%d]  %.1f-> %.1f\n", i, h_in[i], h_out[i]);

	//free GPU memory allocation
	cudaFree(d_in);
	cudaFree(d_out);

	// free CPU memory allocation
	free(h_in);
	free(h_out);
}


