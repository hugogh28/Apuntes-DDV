#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>

__global__ void transpose(float* B, float* A, const size_t WIDTH, const size_t HEIGHT) {

	unsigned int  x = blockIdx.x * blockDim.x + threadIdx.x;
	unsigned int  y = blockIdx.y * blockDim.y + threadIdx.y;

	if ((x < WIDTH) && (y < HEIGHT)) {
		size_t idx = y * WIDTH + x;
		float f = A[idx];

		unsigned int newX = y;
		unsigned int newY = x;
		unsigned int newHeight = WIDTH;
		unsigned int newWidth = HEIGHT;
		unsigned int newIdx = newY * newWidth + newX;

		//unsigned int newIdx = x * HEIGHT + y;
		
		B[newIdx] = f;
	}
}


int main(int argc, char** argv) {

	const size_t WIDTH = 183;
	const size_t HEIGHT = 45;
	const size_t NUM_ELEMENTS = WIDTH * HEIGHT;
	const size_t ARRAY_BYTES = NUM_ELEMENTS * sizeof(float);

	//generate the input array on the host
	float* h_A = (float*)malloc(ARRAY_BYTES);
	for (size_t i = 0; i < NUM_ELEMENTS; i++) {
		h_A[i] = i;
	}

	//declare GPU memory pointers
	float* d_A;
	float* d_B;

	//Allocate GPU memory
	cudaMalloc(&d_A, ARRAY_BYTES);
	cudaMalloc(&d_B, ARRAY_BYTES);

	//Transfer the array to the GPU memory
	cudaMemcpy(d_A, h_A, ARRAY_BYTES, cudaMemcpyHostToDevice);

	//launch the kernel
	const dim3 blockSize(16, 16, 1);
	const dim3 gridSize(ceil((float)WIDTH / blockSize.x), ceil((float)HEIGHT / blockSize.y), 1);
	transpose << <gridSize, blockSize >> > (d_B, d_A, WIDTH, HEIGHT);

	//copy back the result array to the GPU
	float* h_B = (float*)malloc(ARRAY_BYTES);
	cudaMemcpy(h_B, d_B, ARRAY_BYTES, cudaMemcpyDeviceToHost);

	//print out the resulting array
	for (size_t i = 0; i < HEIGHT; i++)
		for (size_t j = 0; j < WIDTH; j++) {
			size_t indexA = i * WIDTH + j;
			size_t indexB = j * HEIGHT + i;
			printf("A[%d][%d] = %.2f, B[%d][%d] = %.2f\n", i, j, h_A[indexA], j, i, h_B[indexB]);
		}

	//free GPU memory allocation
	cudaFree(d_A);
	cudaFree(d_B);

	free(h_A);
	free(h_B);
}


