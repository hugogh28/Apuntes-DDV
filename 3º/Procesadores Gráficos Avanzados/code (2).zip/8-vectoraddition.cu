#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>

__global__ void add (float* d_arr1, float* d_arr2, float* d_out){

	size_t idx = blockIdx.x * blockDim.x + threadIdx.x;

	// miss something here?. Check out of memory index!
	float f1 = d_arr1[idx];
	float f2 = d_arr2[idx];

	d_out[idx] = f1+f2;
}


int main() {

	const unsigned long long ARRAY_SIZE = 100000;
	const unsigned long long ARRAY_BYTES = ARRAY_SIZE * sizeof(float);

	//generate the input arrays on the host
	float* h_arr1 = (float*) malloc(ARRAY_BYTES);
	float* h_arr2 = (float*) malloc(ARRAY_BYTES);

	for (int i = 0; i < ARRAY_SIZE; i++) {
		h_arr1[i] = rand() % 10;
		h_arr2[i] = rand() % 10;
	}

	//declare GPU memory pointers
	float* d_arr1;
	float* d_arr2;
	float* d_out;

	//Allocate GPU memory
	cudaMalloc(&d_arr1, ARRAY_BYTES);
	cudaMalloc(&d_arr2, ARRAY_BYTES);
	cudaMalloc(&d_out, ARRAY_BYTES);

	//Transfer the arrays to the GPU memory
	cudaMemcpy(d_arr1, h_arr1, ARRAY_BYTES, cudaMemcpyHostToDevice);
	cudaMemcpy(d_arr2, h_arr2, ARRAY_BYTES, cudaMemcpyHostToDevice);

	//launch the kernel
	const size_t THREADS_PER_BLOCK = 256; // 128, 256, 512, 1024
	const size_t BLOCKS_PER_GRID = ceil((float)ARRAY_SIZE / THREADS_PER_BLOCK);
	add << <BLOCKS_PER_GRID, THREADS_PER_BLOCK >> > (d_arr1, d_arr2, d_out);

	//copy back the result array to the GPU
	float* h_out = (float*)malloc(ARRAY_BYTES);
	cudaMemcpy(h_out, d_out, ARRAY_BYTES, cudaMemcpyDeviceToHost);

	//print out the resulting array
	for (unsigned long long i = 0; i < ARRAY_SIZE; i++)
		printf("[%llu] -> %.1f + %.1f = %.1f\n", i, h_arr1[i], h_arr2[i], h_out[i]);

	//free GPU memory allocation
	cudaFree(d_arr1);
	cudaFree(d_arr2);
	cudaFree(d_out);

	// free CPU memory allocation
	free(h_arr1);
	free(h_arr2);
	free(h_out);
}


