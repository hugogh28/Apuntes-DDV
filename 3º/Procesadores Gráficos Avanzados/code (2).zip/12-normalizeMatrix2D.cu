#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>

__global__ void normalize (float* B, float* A, const size_t WIDTH, 
				const size_t HEIGHT, const size_t MAX_VALUE){

	size_t x = blockIdx.x * blockDim.x + threadIdx.x;
	size_t y = blockIdx.y * blockDim.y + threadIdx.y;

	if ((x < WIDTH) && (y < HEIGHT)) {
		size_t idx = y * WIDTH + x;
		float f = A[idx];
		B[idx] = f / MAX_VALUE;
	} 
}


int main (int argc, char** argv){

	const size_t WIDTH = 256;
	const size_t HEIGHT = 256;
	const size_t NUM_ELEMENTS = WIDTH * HEIGHT;
	const size_t ARRAY_BYTES = NUM_ELEMENTS * sizeof(float);

	const size_t MAX_VALUE = 255;

	//generate the input array on the host
	float* h_A = (float*) malloc(ARRAY_BYTES);
	for (size_t i=0; i< NUM_ELEMENTS; i++){
		h_A[i] = rand() % MAX_VALUE;
	}

	//declare GPU memory pointers
	float *d_A;
	float *d_B;

	//Allocate GPU memory
	cudaMalloc(&d_A, ARRAY_BYTES);
	cudaMalloc(&d_B, ARRAY_BYTES);

	//Transfer the array to the GPU memory
	cudaMemcpy(d_A, h_A, ARRAY_BYTES, cudaMemcpyHostToDevice);

	//launch the kernel
	const dim3 blockSize(16, 16, 1); 
	const dim3 gridSize(ceil((float) WIDTH / blockSize.x), ceil((float)HEIGHT / blockSize.y), 1);
	normalize<<<gridSize, blockSize >>> (d_B, d_A, WIDTH, HEIGHT, MAX_VALUE);

	//copy back the result array to the GPU
	float* h_B = (float*) malloc(ARRAY_BYTES);
	cudaMemcpy(h_B, d_B, ARRAY_BYTES, cudaMemcpyDeviceToHost);

	//print out the resulting array
	for (size_t i=0; i<HEIGHT; i++)
		for (size_t j=0; j<WIDTH; j++) {
			size_t index = i*WIDTH + j;
			printf("B[%d][%d]= %.1f/%.1f = %.2f\n", i, j, h_A[index], float(MAX_VALUE), h_B[index]);
	}
	
	//free GPU memory allocation
	cudaFree(d_A);
	cudaFree(d_B);

	free(h_A);
	free(h_B);
}


