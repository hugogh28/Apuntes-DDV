#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include "GPUTimer.h"

__host__ __device__ void clamp(int& pos, int maxpos) {
	pos = pos > 0 ? pos : 0;
	pos = pos < (maxpos - 1) ? pos : (maxpos - 1);
}

__global__
void conv2DGPU(float* out, float* const in, int width, int height, const int patternSize)
{
	size_t x = blockIdx.x * blockDim.x + threadIdx.x;
	size_t y = blockIdx.y * blockDim.y + threadIdx.y;

	if (x >= width || y >= height) return;

	int idx = y * width + x;

	int halfPatternSize = patternSize / 2;
	float convResult = 0.0f;
	for (int rowOffset = -halfPatternSize; rowOffset <= halfPatternSize; rowOffset++) {
		for (int colOffset = -halfPatternSize; colOffset <= halfPatternSize; colOffset++) {
			int neighborRow = y + rowOffset;
			clamp(neighborRow, height);

			int neighborCol = x + colOffset;
			clamp(neighborCol, width);

			convResult += in[neighborRow * width + neighborCol];
		}
	}

	out[idx] = convResult/(patternSize* patternSize);

}

void conv2DCPU(float* out, float* in, int width, int height, int patternSize) {

	int halfPatternSize = patternSize / 2;

	for (int row = 0; row < height; row++) {
		for (int col = 0; col < width; col++) {
			float convResult = 0.0f;
			// Apply access pattern to each input coordinate (row, col)
			for (int rowOffset = -halfPatternSize; rowOffset <= halfPatternSize; rowOffset++) {
				for (int colOffset = -halfPatternSize; colOffset <= halfPatternSize; colOffset++) {
					int neighborRow = row + rowOffset;
					clamp(neighborRow, height);

					int neighborCol = col + colOffset;
					clamp(neighborCol, width);

					convResult += in[neighborRow * width + neighborCol];
				}
			}
			// Write the convolution result at the same coordinate (row, col)
			out[col + width * row] = convResult/(patternSize* patternSize);
		}
	}
}

bool checkResults(float* r1, float* r2, int numElements) {
	double EPSILON = 1e-04;

	for (int i = 0; i < numElements; i++) {
		if (fabs(r1[i] - r2[i]) > EPSILON)
			return false;
	}

	return true;
}


int main(int argc, char** argv) {

	const float TRIALS = 10.0f;

	const size_t WIDTH = 256;
	const size_t HEIGHT = 256;
	const size_t NUM_ELEMENTS = WIDTH * HEIGHT;
	const size_t ARRAY_BYTES = NUM_ELEMENTS * sizeof(float);

	const size_t PATTERN_SIZE = 3;
	const size_t MAX_VALUE = 255;

	//generate the input array on the host
	float* h_in = (float*)malloc(ARRAY_BYTES);
	for (size_t i = 0; i < NUM_ELEMENTS; i++) {
		h_in[i] = float(rand() % MAX_VALUE);
	}


	//declare GPU memory pointers
	float* d_in;
	float* d_out;

	//Allocate GPU memory
	cudaMalloc(&d_in, ARRAY_BYTES);
	cudaMalloc(&d_out, ARRAY_BYTES);

	//Transfer the array to the GPU memory
	cudaMemcpy(d_in, h_in, ARRAY_BYTES, cudaMemcpyHostToDevice);

	//launch the pattern
	const dim3 blockSize(16, 16, 1);
	const dim3 gridSize(ceil((float)WIDTH / blockSize.x), ceil((float)HEIGHT / blockSize.y), 1);

	GpuTimer timer;
	timer.Start();
	for (int i = 0; i < TRIALS; i++)
	{
		conv2DGPU << <gridSize, blockSize >> > (d_out, d_in, WIDTH, HEIGHT, PATTERN_SIZE);
	}
	timer.Stop();

	printf("GPU- average time elapsed: %f\n", timer.Elapsed() / (TRIALS * 1000));

	//copy back the result array to the GPU
	float* h_out = (float*)malloc(ARRAY_BYTES);
	cudaMemcpy(h_out, d_out, ARRAY_BYTES, cudaMemcpyDeviceToHost);

	//run conv2D on CPU
	float* h_expectedResult = (float*)malloc(ARRAY_BYTES);
	clock_t t = clock();
	for (int i = 0; i < TRIALS; i++)
	{
		conv2DCPU(h_expectedResult, h_in, WIDTH, HEIGHT, PATTERN_SIZE);
	}
	t = clock() - t;
	printf("CPU - average time elapsed: %f\n", ((float)t) / (TRIALS * CLOCKS_PER_SEC));

	//compare CPU and GPU results.
	bool success = checkResults(h_out, h_expectedResult, NUM_ELEMENTS);
	if (success)
		printf("Conv2D was succesfully computed on GPU and CPU\n");
	else
		printf("Conv2D. Something was wrong. CPU and GPU results show differences\n");

	//free GPU memory allocation
	cudaFree(d_in);
	cudaFree(d_out);

	free(h_in);
	free(h_out);
	free(h_expectedResult);
}

