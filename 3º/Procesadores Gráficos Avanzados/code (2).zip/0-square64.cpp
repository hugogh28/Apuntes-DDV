#include <stdio.h>
//#include <stdlib.h>

void square(const float *in, float *out, size_t s) {
    for (size_t i = 0; i < s; i++)
        out[i] = in[i] * in[i];
}

int main(int argc, char **argv) {

    const size_t ARRAY_SIZE = 64;

    float in[ARRAY_SIZE];
    //float* in = (float*) malloc(ARRAY_SIZE*sizeof(float));
    for (size_t i = 0; i < ARRAY_SIZE; i++)
        in[i] = (float) i;

    float out[ARRAY_SIZE];
    //float* out = (float*) malloc(ARRAY_SIZE*sizeof(float));
    square(in, out, ARRAY_SIZE);

    for (size_t i = 0; i < ARRAY_SIZE; i++)
        printf("%.1f-> %.1f\n", in[i], out[i]);

    //free(in);
    //free(out);
}

