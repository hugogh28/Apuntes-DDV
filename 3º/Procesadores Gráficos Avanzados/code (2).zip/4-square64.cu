#include <cuda_runtime.h>
#include <cstdio>

__global__ void square(float* out, float* in) {

	size_t idx = threadIdx.x;
	float f = in[idx];

	out[idx] = f * f;
}


int main(int argc, char** argv) {

	const size_t ARRAY_SIZE = 64;
	const size_t NUM_THREADS = ARRAY_SIZE;
	const size_t ARRAY_BYTES = ARRAY_SIZE * sizeof(float);

	//generate the input array on the host
	float h_in[ARRAY_SIZE];
	for (size_t i = 0; i < ARRAY_SIZE; i++) {
		h_in[i] = (float)i;
	}

	//declare GPU memory pointers
	float* d_in;
	float* d_out;

	//Allocate GPU memory
	cudaMalloc(&d_in, ARRAY_BYTES);
	cudaMalloc(&d_out, ARRAY_BYTES);

	//Transfer the array to the GPU memory
	cudaMemcpy(d_in, h_in, ARRAY_BYTES, cudaMemcpyHostToDevice);

	//launch the kernel
	square <<<1, NUM_THREADS >>> (d_out, d_in);

	//copy back the result array to the GPU
	float h_out[ARRAY_SIZE];
	cudaMemcpy(h_out, d_out, ARRAY_BYTES, cudaMemcpyDeviceToHost);

	//print out the resulting array
	for (size_t i = 0; i < ARRAY_SIZE; i++)
		printf("%.1f-> %.1f\n", h_in[i], h_out[i]);

	//free GPU memory allocation
	cudaFree(d_in);
	cudaFree(d_out);

	d_in = d_out = NULL;
}

