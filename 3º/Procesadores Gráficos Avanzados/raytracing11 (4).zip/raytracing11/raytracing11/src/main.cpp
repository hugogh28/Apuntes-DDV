#include <iostream>
#include "../include/utils.h"
#include "../include/Vec3.h"
#include "../include/Scene.h"
#include "../include/Ray.h"
#include "../include/Camera.h"
#include "../include/random.h"


int main() {
	int ns = 10;
	int w = 512;
	int h = 256;
	
    size_t size = sizeof(char) * w * h * 3;
	unsigned char* img = (unsigned char*) malloc(size);
	
	Scene world;
	world.setSkyColor(Vec3(0.5f, 0.7f, 1.0f));
	world.setInfColor(Vec3(1.0f, 1.0f, 1.0f));
	world.add(new Object(new Sphere(Vec3(0.0f, -1000.5f, 0.0f), 1000.0f),
                         new Diffuse(Vec3(0.5, 0.5, 0.5))));
	world.add(new Object(new Sphere(Vec3(0.8f, 0.0f, -1.0f), 0.5f),
		                 new Diffuse(Vec3(0.4f, 0.2f, 0.1f))));
	world.add(new Object(new Sphere(Vec3(0.0f, 0.0f, -1.6f), 0.5f),
		                 new Crystalline(1.5f)));
	world.add(new Object(new Sphere(Vec3(-0.8f, 0.0f, -1.0f), 0.5f),
		                 new Metallic(Vec3(0.7f, 0.6f, 0.5f), 0.0f)));
	Vec3 origin(0, 0, 0);
	Vec3 llc(-2, -1, -1);
	Vec3 horizontal(4, 0, 0);
	Vec3 vertical(0, 2, 0);
	
	Camera cam(origin, llc, horizontal, vertical);
	
	for (int i = h - 1; i >= 0; i--) {
		for (int j = 0; j < w; j++) {
			Vec3 col(0, 0, 0);
			for (int s = 0; s < ns; s++) {
				float u = float(j + random()) / float(w);
				float v = float(i + random()) / float(h);
				Ray r = cam.getRay(u, v);
				col += world.getSceneColor(r);
			}
			col /= float(ns);
			col = Vec3(sqrt(col[0]), sqrt(col[1]), sqrt(col[2]));
			
			img[(i * w + j) * 3 + 2] = char(255 * col[0]);
			img[(i * w + j) * 3 + 1] = char(255 * col[1]);
			img[(i * w + j) * 3 + 0] = char(255 * col[2]);
		}
	}
	writeBMP("img.bmp", img, w, h);
	std::cout << "imagen creada" << std::endl;
	free(img);
    return 0;
}

