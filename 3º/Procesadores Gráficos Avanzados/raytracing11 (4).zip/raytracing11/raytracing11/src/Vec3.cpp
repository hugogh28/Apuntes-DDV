#include "../include/Vec3.h"

/*****************************************************************************/
/* Extern operators Functions                                                */
/*****************************************************************************/

Vec3 operator+(Vec3 v1, const Vec3& v2) {
	v1 += v2;
	return (v1);
}

Vec3 operator-(Vec3 v1, const Vec3& v2) {
	v1 -= v2;
	return (v1);
}

Vec3 operator*(Vec3 v1, const Vec3& v2) {
	v1 *= v2;
	return (v1);
}

Vec3 operator/(Vec3 v1, const Vec3& v2) {
	v1 /= v2;
	return (v1);
}

Vec3 operator*(float t, Vec3 v) {
	v *= t;
	return (v);
}

Vec3 operator/(Vec3 v, float t) {
	v /= t;
	return (v);
}

Vec3 operator*(Vec3 v, float t) {
	v *= t;
	return (v);
}

/*****************************************************************************/
/* Friend Functions                                                          */
/*****************************************************************************/

float dot(const Vec3& v1, const Vec3& v2) {
	return v1.e[0] * v2.e[0]
		+ v1.e[1] * v2.e[1]
		+ v1.e[2] * v2.e[2];
}

Vec3 cross(const Vec3& v1, const Vec3& v2) {
	return Vec3(v1.e[1] * v2.e[2] - v1.e[2] * v2.e[1],
		v1.e[2] * v2.e[0] - v1.e[0] * v2.e[2],
		v1.e[0] * v2.e[1] - v1.e[1] * v2.e[0]);
}

/*****************************************************************************/
/* Other Functions                                                          */
/*****************************************************************************/

Vec3 unit_vector(Vec3 v) {
	return v / v.length();
}

std::istream& operator>>(std::istream& is, Vec3& t) {
	is >> t[0] >> t[1] >> t[2];
	return is;
}

std::ostream& operator<<(std::ostream& os, const Vec3& t) {
	os << t[0] << " " << t[1] << " " << t[2];
	return os;
}
