#include "../include/Sphere.h"

bool setCollisionData(float temp, const Ray& ray, float t_min, 
                      float t_max, CollisionData& cd, const Vec3& center, float radius) {
  if (temp < t_max && temp > t_min) {
    cd.time = temp;
    cd.p = ray.point_at_parameter(cd.time);
    cd.normal = (cd.p - center) / radius;
    return true;
  }
  return false;
}


bool Sphere::collide(const Ray& ray, float t_min, float t_max, CollisionData& cd) const {
	Vec3 ac = ray.origin() - center;
	float a = dot(ray.direction(), ray.direction());
	float b = dot(ac, ray.direction());
	float c = dot(ac, ac) - radius * radius;
	float discriminant = b * b - a * c;
	if (discriminant > 0) {
		float temp = (-b - sqrt(discriminant)) / a;
		if (setCollisionData(temp, ray, t_min, t_max, cd, center, radius)) {
			return true;
		}
		temp = (-b + sqrt(discriminant)) / a;
		return setCollisionData(temp, ray, t_min, t_max, cd, center, radius);
	}
	return false;
}
