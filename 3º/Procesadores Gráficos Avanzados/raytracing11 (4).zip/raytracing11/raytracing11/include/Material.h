#pragma once

/*****************************************************************************/
/* Based on the code written in 2016 by Peter Shirley <ptrshrl@gmail.com>    */
/* Check COPYING.txt for copyright license                                   */
/*****************************************************************************/

#include "../include/ray.h"
#include "../include/CollisionData.h"

class Material  {
public:
    virtual bool scatter(const Ray& r_in, const CollisionData& cd, Vec3& attenuation, Ray& scattered) const = 0;
};
