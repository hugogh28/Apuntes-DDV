#pragma once

#include "../include/Shape.h"
#include "../include/Material.h"

class Object {
public:
	Object(Shape* shape, Material* material) : s(shape), m(material) {}

	bool checkCollision(const Ray& ray, float t_min, float t_max, CollisionData& cd) {
		return (s->collide(ray, t_min, t_max, cd));
	}

	bool scatter(const Ray& r_in, const CollisionData& cd, Vec3& attenuation, Ray& scattered) {
		return (m->scatter(r_in, cd, attenuation, scattered));
	}

private:
	Shape* s;
	Material* m;
};
