#pragma once

#include "../include/Vec3.h"
#include "../include/Material.h"
#include "../include/random.h"

class Diffuse : public Material {
public:
	Diffuse(const Vec3& color) : color(color) {}

	bool scatter(const Ray& r_in, const CollisionData& cd, Vec3& attenuation, Ray& scattered) const {
		Vec3 target = cd.normal + randomNormalSphere();
		scattered = Ray(cd.p, target);
		attenuation = color;
		return true;
	}
private:
	Vec3 color;
};
