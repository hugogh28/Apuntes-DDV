#pragma once

#include "../include/utils.h"
#include "../include/random.h"

#include "../include/Material.h"

class Crystalline : public Material {
public:
	Crystalline(float ri) : ref_idx(ri) {}

	bool scatter(const Ray& r_in, const CollisionData& cd, Vec3& attenuation, Ray& scattered) const;

private:
	float ref_idx;
};

