#pragma once

#include "../include/vec3.h"

inline float random() { return rand() / (RAND_MAX + 1.0f); }
Vec3 randomNormalSphere();
Vec3 randomNormalDisk();
