#pragma once

#include <vector>
#include <limits>
#include "../include/Vec3.h"
#include "../include/Ray.h"
#include "../include/Object.h"
#include "../include/Sphere.h"
#include "../include/Material.h"
#include "../include/Diffuse.h"
#include "../include/Metallic.h"
#include "../include/Crystalline.h"

class Scene {
public:
	Scene(int depth=50) : sky(), inf(), d(depth) {}
	Scene(const Scene& list) = default;

	void add(Object* h) { ol.push_back(h); }
	void setSkyColor(Vec3 sky) { this->sky = sky; }
	void setInfColor(Vec3 inf) { this->inf = inf; }

	Vec3 getSceneColor(const Ray& r);

protected:
	Vec3 getSceneColor(const Ray& r, int depth);

private:
	Vec3 sky;
	Vec3 inf;
	std::vector<Object*> ol;
	int d;
};
