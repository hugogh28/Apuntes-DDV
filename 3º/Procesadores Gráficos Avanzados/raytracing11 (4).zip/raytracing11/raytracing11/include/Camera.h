#pragma once

//==================================================================================================
// Written in 2016 by Peter Shirley <ptrshrl@gmail.com>
//
// To the extent possible under law, the author(s) have dedicated all copyright and related and
// neighboring rights to this software to the public domain worldwide. This software is distributed
// without any warranty.
//
// You should have received a copy (see file COPYING.txt) of the CC0 Public Domain Dedication along
// with this software. If not, see <http://creativecommons.org/publicdomain/zero/1.0/>.
//==================================================================================================

#include "../include/Vec3.h"
#include "../include/ray.h"

class Camera {
public:
    Camera(Vec3 origin, Vec3 llc, Vec3 horizontal, Vec3 vertical) : origin(origin), lower_left_corner(llc), horizontal(horizontal), vertical(vertical) {}
    Ray getRay(float u, float v) {

        return Ray(origin, lower_left_corner + u * horizontal + v * vertical);
    }

private:
    Vec3 origin;
    Vec3 lower_left_corner;
    Vec3 horizontal;
    Vec3 vertical;
};
