const express = require('express');
const { WebSocketServer } = require('ws');
const http = require('http');

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// Serve a simple HTML client for testing
app.get('/', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>WebSocket Echo Server</title>
      <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
        #messages { border: 1px solid #ccc; height: 300px; overflow-y: auto; padding: 10px; margin: 20px 0; }
        input { width: 70%; padding: 10px; }
        button { padding: 10px 20px; }
        .sent { color: blue; }
        .received { color: green; }
      </style>
    </head>
    <body>
      <h1>WebSocket Echo Server</h1>
      <div id="messages"></div>
      <input type="text" id="messageInput" placeholder="Type a message...">
      <button onclick="sendMessage()">Send</button>
      
      <script>
        const ws = new WebSocket('ws://' + window.location.host);
        const messages = document.getElementById('messages');
        const input = document.getElementById('messageInput');
        
        ws.onopen = () => {
          addMessage('Connected to server', 'system');
        };
        
        ws.onmessage = (event) => {
          addMessage('Echo: ' + event.data, 'received');
        };
        
        ws.onclose = () => {
          addMessage('Disconnected from server', 'system');
        };
        
        function sendMessage() {
          const message = input.value;
          if (message && ws.readyState === WebSocket.OPEN) {
            ws.send(message);
            addMessage('You: ' + message, 'sent');
            input.value = '';
          }
        }
        
        function addMessage(text, type) {
          const div = document.createElement('div');
          div.className = type;
          div.textContent = text;
          messages.appendChild(div);
          messages.scrollTop = messages.scrollHeight;
        }
        
        input.addEventListener('keypress', (e) => {
          if (e.key === 'Enter') sendMessage();
        });
      </script>
    </body>
    </html>
  `);
});

// WebSocket connection handler
wss.on('connection', (ws) => {
  console.log('Client connected');
  
  // Echo back any message received
  ws.on('message', (message) => {
    console.log('Received:', message.toString());
    ws.send(message.toString());
  });
  
  ws.on('close', () => {
    console.log('Client disconnected');
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Echo server running on http://localhost:${PORT}`);
});