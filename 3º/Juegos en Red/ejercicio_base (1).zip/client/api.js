/**
 * API Client para comunicación con el servidor
 * Este archivo contiene funciones para realizar peticiones HTTP al servidor
 *
 * IMPORTANTE: Las funciones están definidas pero NO implementadas.
 * Debes implementar cada función usando fetch() o la librería que prefieras.
 */

const API_BASE_URL = 'http://localhost:3000';

// ==================== USUARIOS ====================

/**
 * Registra un nuevo usuario en el sistema
 * @param {Object} userData - Datos del usuario {email, name, avatar, level}
 * @returns {Promise<Object>} - Usuario creado
 */
export async function registerUser(userData) {
  const response = await fetch(`${API_BASE_URL}/api/users`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(userData)
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Error al registrar usuario');
  }

  return await response.json();
}

/**
 * Obtiene un usuario por su ID
 * @param {string} userId - ID del usuario
 * @returns {Promise<Object>} - Usuario encontrado
 */
export async function getUser(userId) {
  // TODO: Implementar petición GET a /api/users/:id
  // Retornar: usuario o lanzar error si no existe
  throw new Error('getUser() no implementado');
}

/**
 * Obtiene todos los usuarios
 * @returns {Promise<Array>} - Array de usuarios
 */
export async function getAllUsers() {
  // TODO: Implementar petición GET a /api/users
  // Retornar: array de usuarios
  throw new Error('getAllUsers() no implementado');
}

/**
 * Actualiza un campo específico de un usuario
 * @param {string} userId - ID del usuario
 * @param {Object} updates - Objeto con los campos a actualizar
 * @returns {Promise<Object>} - Usuario actualizado
 */
export async function updateUser(userId, updates) {
  // TODO: Implementar petición PUT a /api/users/:id
  // Body: updates (JSON)
  // Retornar: usuario actualizado
  throw new Error('updateUser() no implementado');
}

/**
 * Elimina un usuario del sistema
 * @param {string} userId - ID del usuario
 * @returns {Promise<void>}
 */
export async function deleteUser(userId) {
  // TODO: Implementar petición DELETE a /api/users/:id
  // Retornar: confirmación o lanzar error
  throw new Error('deleteUser() no implementado');
}

// ==================== MENSAJES ====================

/**
 * Envía un mensaje al chat
 * @param {string} userEmail - Email del usuario que envía
 * @param {string} message - Contenido del mensaje
 * @returns {Promise<Object>} - Mensaje creado
 */
export async function sendMessage(userEmail, message) {
  // TODO: Implementar petición POST a /api/messages
  // Body: {email: userEmail, message: message}
  // El servidor debe verificar que el email existe
  // Retornar: mensaje creado con timestamp
  throw new Error('sendMessage() no implementado');
}

/**
 * Obtiene los últimos mensajes del chat
 * @param {number} limit - Número máximo de mensajes a obtener (default: 50)
 * @returns {Promise<Array>} - Array de mensajes
 */
export async function getMessages(limit = 50) {
  // TODO: Implementar petición GET a /api/messages?limit=X
  // Retornar: array de mensajes ordenados por timestamp
  throw new Error('getMessages() no implementado');
}

/**
 * Obtiene mensajes desde un timestamp específico (para polling)
 * @param {string} since - Timestamp ISO desde el cual obtener mensajes
 * @returns {Promise<Array>} - Array de mensajes nuevos
 */
export async function getMessagesSince(since) {
  // TODO: Implementar petición GET a /api/messages?since=X
  // Útil para implementar polling y obtener solo mensajes nuevos
  // Retornar: array de mensajes nuevos
  throw new Error('getMessagesSince() no implementado');
}
