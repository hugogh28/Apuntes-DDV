# Ejercicio: Sistema de Chat para Videojuego

## Descripción General

En este ejercicio desarrollarás un sistema completo de chat para un videojuego, compuesto por:
- **Cliente CLI**: Interfaz de línea de comandos para interactuar con el sistema
- **Servidor REST API**: Backend que gestiona usuarios y mensajes

El objetivo es practicar:
- Comunicación HTTP con APIs REST
- Uso de closures en JavaScript
- Arquitectura cliente-servidor
- Operaciones CRUD
- Gestión de estado en memoria

---

## Estructura del Proyecto

```
rest_exercises/
├── package.json
├── client/
│   └── api.js            (Parcial - registerUser implementado como ejemplo)
└── server/
    ├── index.js          (Implementado - Servidor Express con DI)
    ├── routes/
    │   ├── users.js      (Implementado - Rutas de usuarios)
    │   └── messages.js   (Implementado - Rutas de mensajes)
    ├── controllers/
    │   ├── userController.js    (Parcial - create, getById implementados)
    │   └── messageController.js (TODO - Controlador mensajes)
    └── services/
        ├── userService.js       (Parcial - createUser, getUserById implementados)
        └── messageService.js    (TODO - Servicio mensajes)
```

---

## Modelo de Datos

### Usuario
```javascript
{
  id: string,           // ID único (ej: "1", "2", "3")
  email: string,        // Email del usuario (único)
  name: string,         // Nombre del jugador
  avatar: string,       // URL del avatar
  level: number,        // Nivel del jugador
  createdAt: string     // Timestamp ISO de creación
}
```

### Mensaje
```javascript
{
  id: string,           // ID único
  email: string,        // Email del usuario que envía
  message: string,      // Contenido del mensaje
  timestamp: string     // Timestamp ISO
}
```

---

## Parte 1: Implementar Cliente HTTP (client/api.js)

### Instrucciones

Debes implementar **las funciones restantes** en `client/api.js` usando `fetch()` o la librería que prefieras.

**NOTA**: `registerUser()` ya está implementada como ejemplo. Úsala como referencia para implementar las demás.

### Funciones a Implementar

#### Usuarios

1. **`registerUser(userData)`** (IMPLEMENTADA COMO EJEMPLO)
   - Método: `POST /api/users`
   - Body: `{email, name, avatar, level}`
   - Retorna: Usuario creado

2. **`getUser(userId)`**
   - Método: `GET /api/users/:id`
   - Retorna: Usuario encontrado

3. **`getAllUsers()`**
   - Método: `GET /api/users`
   - Retorna: Array de usuarios

4. **`updateUser(userId, updates)`**
   - Método: `PUT /api/users/:id`
   - Body: Campos a actualizar
   - Retorna: Usuario actualizado

5. **`deleteUser(userId)`**
   - Método: `DELETE /api/users/:id`

#### Mensajes

6. **`sendMessage(userEmail, message)`**
   - Método: `POST /api/messages`
   - Body: `{email, message}`
   - Retorna: Mensaje creado

7. **`getMessages(limit)`**
   - Método: `GET /api/messages?limit=X`
   - Retorna: Últimos N mensajes

8. **`getMessagesSince(since)`**
   - Método: `GET /api/messages?since=X`
   - Retorna: Mensajes nuevos desde timestamp

### Ejemplo de Implementación

La función `registerUser()` ya está implementada en `client/api.js`. Úsala como referencia:

```javascript
export async function registerUser(userData) {
  const response = await fetch(`${API_BASE_URL}/api/users`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(userData)
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Error al registrar usuario');
  }

  return await response.json();
}
```

**Puntos clave**:
- Usar `fetch()` con la URL completa
- Configurar method, headers y body
- Validar `response.ok` antes de parsear
- Lanzar errores descriptivos para manejo en el cliente

---

## Parte 2: Implementar Servicio de Usuarios (server/services/userService.js)

### Instrucciones

Implementa **los métodos restantes** del servicio de usuarios usando closures.

**NOTA**: `createUser()` ya está implementado como ejemplo. Úsalo como referencia para implementar los demás.

### Requisitos

1. **Variables privadas** dentro de la closure:
   - `users = []` - Array para almacenar usuarios
   - `nextId = 1` - Contador para IDs únicos

2. **Métodos a implementar**:

#### `createUser(userData)` (IMPLEMENTADO COMO EJEMPLO)
- Validar que el email no exista
- Crear usuario con estructura:
  ```javascript
  {
    id: String(nextId++),
    email: userData.email,
    name: userData.name,
    avatar: userData.avatar || '',
    level: userData.level || 1,
    createdAt: new Date().toISOString()
  }
  ```
- Agregar a `users`
- Retornar usuario creado

#### `getAllUsers()`
- Retornar copia del array de usuarios

#### `getUserById(id)` (IMPLEMENTADO COMO EJEMPLO)
- Buscar usuario por ID
- Retornar usuario o `null`

#### `getUserByEmail(email)`
- Buscar usuario por email
- Retornar usuario o `null`
- **IMPORTANTE**: Será usado por el chat para validar emails

#### `updateUser(id, updates)`
- Buscar usuario por ID
- Actualizar **solo** campos permitidos: `name`, `avatar`, `level`
- **NO** actualizar: `id`, `email`, `createdAt`
- Retornar usuario actualizado o `null`

#### `deleteUser(id)`
- Buscar y eliminar usuario
- Retornar `true` si se eliminó, `false` si no existía

---

## Parte 3: Implementar Controlador de Usuarios (server/controllers/userController.js)

### Instrucciones

Implementa **los métodos restantes** del controlador usando closures.

**NOTA**: `create()` ya está implementado como ejemplo. Úsalo como referencia para implementar los demás.

### Métodos a Implementar

#### `create(req, res, next)` (IMPLEMENTADO COMO EJEMPLO)
- Extraer datos de `req.body`
- Validar campos requeridos (`email`, `name`)
- Llamar a `userService.createUser()`
- Responder:
  - `201` con usuario creado si éxito
  - `400` si faltan campos o email duplicado

#### `getAll(req, res, next)`
- Llamar a `userService.getAllUsers()`
- Responder `200` con array de usuarios

#### `getById(req, res, next)` (IMPLEMENTADO COMO EJEMPLO)
- Extraer `id` de `req.params`
- Llamar a `userService.getUserById()`
- Responder:
  - `200` con usuario si existe
  - `404` si no existe

#### `update(req, res, next)`
- Extraer `id` de `req.params`
- Extraer updates de `req.body`
- Llamar a `userService.updateUser()`
- Responder:
  - `200` con usuario actualizado si existe
  - `404` si no existe

#### `remove(req, res, next)`
- Extraer `id` de `req.params`
- Llamar a `userService.deleteUser()`
- Responder:
  - `204` si se eliminó
  - `404` si no existía

---

## Parte 4: Implementar Sistema de Mensajes (messageService.js y messageController.js)

### Instrucciones

Implementa **completamente** el servicio y controlador de mensajes siguiendo los patrones de usuarios.

### messageService.js

Variables privadas:
```javascript
let messages = [];
let nextId = 1;
```

Métodos:

#### `createMessage(email, message)`
1. Verificar que el usuario existe:
   ```javascript
   const user = userService.getUserByEmail(email);
   if (!user) throw new Error('Usuario no encontrado');
   ```
2. Crear mensaje:
   ```javascript
   {
     id: String(nextId++),
     email,
     message,
     timestamp: new Date().toISOString()
   }
   ```
3. Agregar a array y retornar

#### `getRecentMessages(limit)`
- Retornar últimos `limit` mensajes
- Ordenados por timestamp (más recientes primero)

#### `getMessagesSince(since)`
- Filtrar mensajes con `timestamp > since`
- Ordenados por timestamp

### messageController.js

#### `create(req, res, next)`
- Extraer `email` y `message` de `req.body`
- Validar ambos campos presentes
- Llamar a `messageService.createMessage()`
- Responder:
  - `201` con mensaje creado
  - `400` si faltan campos o email no existe

#### `getMessages(req, res, next)`
- Si `req.query.since` existe: usar `getMessagesSince()`
- Si no: usar `getRecentMessages(req.query.limit || 50)`
- Responder `200` con mensajes

---

## Instrucciones de Ejecución

### 1. Instalar Dependencias
```bash
npm install
```

### 2. Iniciar el Servidor
```bash
npm start
```
Debe mostrar:
```
========================================
  SERVIDOR DE CHAT PARA VIDEOJUEGO
========================================
  Servidor corriendo en http://localhost:3000
  Endpoints disponibles:
   - GET    /health
   - GET    /api/users
   - POST   /api/users
   ...
```

### 3. Probar la API

Abre el REPL de Node.js en otra terminal:

```bash
node
```

Luego importa y usa tu API:

```javascript
// Importar tu cliente API
const api = await import('./client/api.js');

// Registrar un usuario
const user = await api.registerUser({
  email: 'player1@game.com',
  name: 'Player One',
  avatar: 'https://avatar.url/1.png',
  level: 5
});
console.log('Usuario creado:', user);

// Obtener usuario por ID
const found = await api.getUser(user.id);
console.log('Usuario encontrado:', found);

// Listar todos los usuarios
const users = await api.getAllUsers();
console.log('Total usuarios:', users.length);

// Actualizar usuario
const updated = await api.updateUser(user.id, { level: 10 });
console.log('Usuario actualizado:', updated);

// Enviar mensaje
const msg = await api.sendMessage('player1@game.com', 'Hola mundo!');
console.log('Mensaje enviado:', msg);

// Obtener mensajes
const messages = await api.getMessages();
console.log('Mensajes:', messages);

// Eliminar usuario
await api.deleteUser(user.id);
```

**Nota**: Asegúrate de que el servidor esté corriendo en otra terminal antes de probar la API.

---