#include "vector3d.h"

Vector3D Vector3D::suma(Vector3D v) {
    Vector3D r;
    r.x = this->x + v.x;
    r.y = this->y + v.y;
    r.z = this->z + v.z;
    return r;
}
Vector3D Vector3D::resta(Vector3D v) {
    Vector3D r;
    r.x = x - v.x;
    r.y = y - v.y;
    r.z = z - v.z;
    return r;
}
double Vector3D::multiply(Vector3D v) {
    double d;
    d = x * v.x + y * v.y + z * v.z;
    return d;
}
Vector3D Vector3D::multiply(double d) {
    Vector3D r;
    r.x = x * d;
    r.y = y * d;
    r.z = z * d;
    return r;
}
Vector3D Vector3D::divide(double d) {
    Vector3D r;
    r.x = x / d;
    r.y = y / d;
    r.z = z / d;
    return r;
}
double Vector3D::norm2() {
    double d;
    Vector3D self;
    self = *this;
    // d= this->multiply(*this);
    d = self.multiply(self);
    return d;
}
double Vector3D::length() {
    Vector3D self;
    self = *this;
    double l;
    //l=sqrt((*this).norm2());
    //l=sqrt(this->norm2());
    l = sqrt(self.norm2());
    return l;
}
Vector3D Vector3D::normalized() {
    Vector3D self;
    self = *this;
    double l;
    l = self.length();
    Vector3D n;
    n = self.divide(l);
    return n;
}
void Vector3D::normalize() {
    Vector3D self;
    self = *this;
    Vector3D n;
    n = self.normalized();
    *this = n;
}
void Vector3D::imprimir() {
    cout << this->x << "," << this->y << "," << this->z;
}

// Funciones �OJO! NO m�todos

/*void imprimir(Vector3D v) {
    cout << v.getX() << "," << v.getY() << "," << v.getZ();
}*/

void imprimir(Vector3D v) {
    cout << v.x << "," << v.y << "," << v.z;
}
ostream& operator<<(ostream& o, const Vector3DRef v) {
    o << v.x << " " << v.y << " " << v.z;
    return o;
}
istream& operator>>(istream & i, Vector3DRef v) {
    i >> v.x >> v.y >> v.z;
    return i;
}
