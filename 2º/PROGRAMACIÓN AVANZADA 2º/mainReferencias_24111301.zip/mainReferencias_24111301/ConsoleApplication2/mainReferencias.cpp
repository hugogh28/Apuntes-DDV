// ConsoleApplication1.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//
#include <iostream>
#include <fstream>
#include <vector> // STL
#include "vector3d.h"

using namespace std;

void duplicate(int& a,int& b,int& c)
{
    a =a* 2;
    b =b* 2;
    c =c* 2;
}

int main(){
    
    int x = 1, y = 3, z = 7;
    int& rx =x;
    duplicate(rx, y, z);
    cout << "x=" << x << ", y=" << y << ", z=" << z<< endl;


    long l=8;
    vector<int> vi = { 2,3,4 };
    for (unsigned int i = 0; i < vi.size(); i++) {
        int& v = vi[i];
        v *= 2;
        cout << "vi[" << i << "]=" << vi[i] << "- v="<< v <<endl;
    }
    for (int& v : vi) {
        cout << "vi[?]=" << v << endl;
    }
    for (vector<int>::iterator it = vi.begin(); it < vi.end(); it++) {
        int& v = *it;
        cout << "vi[?]=" << v << endl;
    }
    vector<int>::iterator itf = find(vi.begin(), vi.end(), 3);
    if (itf != vi.end()) {
        vi.erase(itf);
    }
    for (int v : vi) {
        cout << "vi[?]=" << v << endl;
    }

    vector<Vector3D> puntos = { {1, 3, 6}, {1, 3, 9} };
    puntos.push_back(Vector3D(1, 3, 4));
    puntos.push_back(Vector3D(2, 3, 4));
    Vector3D v0 = { 1,2,1 };
    Vector3D v1(1,1,1);
    v1.imprimir();
    imprimir(v1);
    std::cout << "Hello Vectort3D!"<<endl;
    cout << "Dime los tres valores de un vector " << endl;
    cin >> v0;
    cout << "Vector0 =" << v0 << endl;
    cout << "Vector1 =" << v1 << endl;
    double cx = v1.getX();
    cx = cx * 2;
    v1.setX(6);
    v1[0] = 7;
    cout << "Vector1.x=" << v1[0] << " cx="<<cx<<endl;
    Vector3D v2;
    v2 = v0.suma(v1);
    cout << "Vector2 =" << v2 << endl;
    Vector3D v3{ 0,0,0 };
    v3 = v0.normalized();
    cout << "Vector3 =" << v3 << endl;
    v1.normalize();
    cout << "Vector1 =" << v1 << endl;
    cout << "Vector1 length=" << v1.length() << endl;
    ofstream f("misVectores.txt");
    f << v1 << endl;
    f << v2 << endl;
    f << v3 << endl;
    f.close();
    ifstream fi("misVectores.txt");
    fi >> v1;
    fi >> v2;
    fi >> v3;
    fi.close();
    cout << v1 << endl << v2 << endl << v3 << endl;
}

// Ejecutar programa: Ctrl + F5 o menú Depurar > Iniciar sin depurar
// Depurar programa: F5 o menú Depurar > Iniciar depuración

// Sugerencias para primeros pasos: 1. Use la ventana del Explorador de soluciones para agregar y administrar archivos
//   2. Use la ventana de Team Explorer para conectar con el control de código fuente
//   3. Use la ventana de salida para ver la salida de compilación y otros mensajes
//   4. Use la ventana Lista de errores para ver los errores
//   5. Vaya a Proyecto > Agregar nuevo elemento para crear nuevos archivos de código, o a Proyecto > Agregar elemento existente para agregar archivos de código existentes al proyecto
//   6. En el futuro, para volver a abrir este proyecto, vaya a Archivo > Abrir > Proyecto y seleccione el archivo .sln
