#pragma once
//#ifndef __VECTOR3D__
//#define __VECTOR3D__
#include <iostream>
using namespace std;

class Vector3D;
typedef Vector3D* Vector3DPtr;
typedef Vector3D& Vector3DRef;

class Vector3D {
private:
    double x, y, z;
public:
    Vector3D(double dx=0, double dy=0, double dz=0):x(dx),y(dy),z(dz) {}
    //Vector3D(double dx, double dy , double dz ) :x(dx), y(dy), z(dz) {}
    //Vector3D(double dx, double dy) :x(dx), y(dy), z(0) {}
    //Vector3D(double dx) :x(dx), y(0), z(0) {}
    //Vector3D() :x(0), y(0), z(0) {}
    inline const double& getX() { return x; }
    inline const double& getY() { return y; }
    inline const double& getZ() { return z; }
    inline void setX(const double& x) { this->x = x; }
    inline void setY(const double& d) { y = d; }
    inline void setZ(const double& d) { this->z = d; }
    double& operator[](int i){
        if (i == 0) return x;
        if (i == 1) return y;
        if (i == 2) return z;
    }
    Vector3D suma(Vector3D v);
    Vector3D resta(Vector3D v);
    double multiply(Vector3D v);
    Vector3D multiply(double d);
    Vector3D divide(double d);
    double norm2();
    double length();
    Vector3D normalized();
    void normalize();
    void imprimir();
    friend void imprimir(Vector3D v);
    friend ostream& operator<<(ostream& o, const Vector3DRef v);
};
//void imprimir(Vector3D v);
//ostream& operator<<(ostream& o, const Vector3DRef v);
//#endif